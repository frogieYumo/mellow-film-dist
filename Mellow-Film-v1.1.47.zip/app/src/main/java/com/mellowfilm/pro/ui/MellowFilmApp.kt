package com.mellowfilm.pro.ui
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.BiasAlignment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.net.Uri
import android.view.TextureView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.ui.res.painterResource
import com.mellowfilm.pro.R
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.mellowfilm.pro.camera.CameraEngine
import com.mellowfilm.pro.camera.FlashMode
import com.mellowfilm.pro.filter.FilmMode
import com.mellowfilm.pro.filter.FilterSettings
import com.mellowfilm.pro.data.prefs.AppPrefs
import com.mellowfilm.pro.data.prefs.PhotoQuality
import com.mellowfilm.pro.data.prefs.VideoAspect
import com.mellowfilm.pro.data.prefs.VideoQuality
import com.mellowfilm.pro.filter.DateStampRenderer
import com.mellowfilm.pro.filter.DateStampStyle
import com.mellowfilm.pro.gallery.GalleryScreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MellowFilmApp(viewModel: MellowFilmViewModel) {
    val screenState by viewModel.screenState.collectAsState()

    val showBatchDialog by viewModel.showBatchDialog.collectAsState()
    // 取り込みは、確認画面を閉じるまで押せないようにする(二重押しの対策)
    var importBusy by remember { mutableStateOf(false) }
    LaunchedEffect(showBatchDialog) { if (!showBatchDialog) importBusy = false }

    // 取り込み(複数の画像を選ぶ)。ギャラリーの「取り込み」から使う
    val multiImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.onBatchImagesSelected(uris)
        } else {
            importBusy = false
        }
    }

    val currentMode by viewModel.currentMode.collectAsState()
    val batchProgress by viewModel.batchProgress.collectAsState()
    val firstBatchPreview by viewModel.firstBatchPreview.collectAsState()
    val batchUris by viewModel.batchUris.collectAsState()

    // Android 15 以降は画面がステータスバー・ナビゲーションバーの裏まで描かれるので、その分の余白を入れる(Android 14 以前は変えない)
    Box(modifier = Modifier.fillMaxSize().then(if (android.os.Build.VERSION.SDK_INT >= 35) Modifier.systemBarsPadding() else Modifier)) {
        when (screenState) {
            ScreenState.CAMERA -> CameraScreen(viewModel)
            ScreenState.GALLERY -> GalleryScreen(
                dao = viewModel.database.filmPhotoDao(),
                onBackToCamera = { viewModel.setScreenState(ScreenState.CAMERA) },
                // 取り込みは、ギャラリーの「取り込み」から。確認画面もここに出す
                onImportBatch = {
                    if (!importBusy) {
                        importBusy = true
                        multiImagePicker.launch("image/*")
                    }
                },
                importEnabled = !importBusy
            )
        }

            // 取り込みの確認(ダークモード・見出しは2行・選択肢は5つ)
            if (showBatchDialog && firstBatchPreview != null) {
                // 開くたびに、FUJI(KODAで開いたときは KODA)・チェックなしから始める
                var batchFilm by remember { mutableStateOf<FilmMode?>(null) }
                var batchDateOnly by remember { mutableStateOf(false) }
                var batchCrop by remember { mutableStateOf(false) }
                var batchFrame by remember { mutableStateOf(false) }
                var showNoneDialog by remember { mutableStateOf(false) }
                // 選び直したら、1枚目のプレビューを作り直す
                fun refreshPreview() = viewModel.updateBatchPreview(batchDateOnly, batchCrop, batchFilm, batchFrame)
                LaunchedEffect(Unit) { refreshPreview() }

                DarkAlertDialog(
                    onDismissRequest = { viewModel.cancelBatchProcessing() },
                    title = {
                        Column {
                            Text("複数画像の一括現像", fontWeight = FontWeight.Bold)
                            Text("(${batchUris.size}枚)", fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(modifier = Modifier.height(4.dp))
                            firstBatchPreview?.let { bmp ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(220.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    androidx.compose.foundation.Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "プレビュー",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "編集方法を選択してください。",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = DarkDialogText
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                                // FUJI・KODA はどちらか1つ。「日付のみ」のときは選べない(2列に並べる)
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    BatchOptionRow("FUJIで現像", checked = !batchDateOnly && batchFilm == FilmMode.FUJI, enabled = !batchDateOnly, modifier = Modifier.weight(1f)) {
                                        batchFilm = if (batchFilm == FilmMode.FUJI) null else FilmMode.FUJI
                                        refreshPreview()
                                    }
                                    BatchOptionRow("KODAで現像", checked = !batchDateOnly && batchFilm == FilmMode.KODA, enabled = !batchDateOnly, modifier = Modifier.weight(1f)) {
                                        batchFilm = if (batchFilm == FilmMode.KODA) null else FilmMode.KODA
                                        refreshPreview()
                                    }
                                }
                                BatchOptionRow("日付のみ", checked = batchDateOnly, enabled = true) {
                                    batchDateOnly = !batchDateOnly
                                    refreshPreview()
                                }
                                BatchOptionRow("3:4でトリミングする", checked = batchCrop, enabled = true) {
                                    batchCrop = !batchCrop
                                    refreshPreview()
                                }
                                BatchOptionRow("フレームを合成する", checked = batchFrame, enabled = true) {
                                    batchFrame = !batchFrame
                                    refreshPreview()
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "2枚目以降はバックグラウンドで連続現像されます。",
                                fontSize = 11.sp,
                                color = Color(0xFFFF8C00)
                            )
                        }
                    },
                    confirmButton = {
                        // 一行で表示する(入りきらないときは文字を小さくする)
                        Button(
                            onClick = {
                                if (batchFilm == null && !batchDateOnly && !batchFrame) {
                                    showNoneDialog = true
                                } else viewModel.confirmBatchProcessing(
                                    dateOnly = batchDateOnly,
                                    crop = batchCrop,
                                    film = batchFilm,
                                    frame = batchFrame
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8C00))
                        ) {
                            Text(
                                "加工して保存",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { viewModel.cancelBatchProcessing() }) {
                            Text("キャンセル", color = Color(0xFF5C5C5C))
                        }
                    }
                )

                if (showNoneDialog) {
                    DarkAlertDialog(
                        onDismissRequest = { showNoneDialog = false },
                        title = { Text("選択されていません", fontWeight = FontWeight.Bold) },
                        confirmButton = {
                            TextButton(onClick = { showNoneDialog = false }) { Text("OK") }
                        }
                    )
                }
            }

            // Batch Progress Indicator HUD
            if (batchProgress.isRunning) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xCC000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .background(Color(0xFF22201D), RoundedCornerShape(12.dp))
                            .padding(24.dp)
                    ) {
                        CircularProgressIndicator(color = Color(0xFFFF8C00))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "一括現像中... (${batchProgress.current}/${batchProgress.total})",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = batchProgress.currentFileName,
                            color = Color(0xFFAAAAAA),
                            fontSize = 11.sp
                        )
                    }
                }
            }

        // 一言メッセージ(保存しました等)をプレビューの真ん中に出す(2.5秒、スワイプで消せる)
        val toast by viewModel.toastMessage.collectAsState()
        LaunchedEffect(toast) {
            if (toast != null) {
                delay(2500L)
                viewModel.clearToast()
            }
        }
        toast?.let { msg ->
            val dismissState = rememberSwipeToDismissBoxState(
                confirmValueChange = { value ->
                    if (value != SwipeToDismissBoxValue.Settled) viewModel.clearToast()
                    true
                }
            )
            SwipeToDismissBox(
                state = dismissState,
                backgroundContent = {},
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
            ) {
                Text(
                    text = msg,
                    color = Color.Black,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF5B82E), RoundedCornerShape(8.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }

    }
}

@Composable
fun CameraScreen(viewModel: MellowFilmViewModel) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    // ビネット・グレインの調整バーが開いているか(開いている間は差し込み画像を薄くする)
    var overlayBarOpen by remember { mutableStateOf(false) }
    val panelAlpha by animateFloatAsState(
        targetValue = if (overlayBarOpen) 0f else 1f,
        animationSpec = tween(durationMillis = 250),
        label = "panelAlpha"
    )
    // タップ位置の赤い印(位置と、連続タップで変わる番号)。3秒で消える
    var tapMarker by remember { mutableStateOf<Pair<Offset, Int>?>(null) }
    LaunchedEffect(tapMarker) {
        if (tapMarker != null) {
            delay(3000L)
            tapMarker = null
        }
    }

    val currentMode by viewModel.currentMode.collectAsState()
    val flashMode by viewModel.flashMode.collectAsState()
    val dateStampEnabled by viewModel.dateStampEnabled.collectAsState()
    val filterSettings by viewModel.filterSettings.collectAsState()
    val exposureEV by viewModel.exposureEV.collectAsState()
    val shutterFlash by viewModel.shutterFlash.collectAsState()
    val timerEnabled by viewModel.timerEnabled.collectAsState()
    val lensOnState by viewModel.lensOn.collectAsState()
    val lensPending by com.mellowfilm.pro.camera.LensShare.pending.collectAsState()
    val timerSeconds by viewModel.timerSeconds.collectAsState()
    val countdown by viewModel.countdown.collectAsState()
    val scannedQr by viewModel.scannedQrCode.collectAsState()
    val orientation by viewModel.deviceOrientation.collectAsState()
    val batchProgress by viewModel.batchProgress.collectAsState()
    val firstBatchPreview by viewModel.firstBatchPreview.collectAsState()
    val batchUris by viewModel.batchUris.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingSeconds by viewModel.recordingSeconds.collectAsState()
    val videoAspect by viewModel.prefs.videoAspect.collectAsState()
    // 標準動画を16:9で録る時だけ、4:3枠の中に黒帯を入れる
    val isWide = currentMode == FilmMode.MOV && videoAspect == VideoAspect.WIDE_16_9

    var showSettingsDialog by remember { mutableStateOf(false) }

    // QR Image Picker Launcher
    val qrImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val contentResolver = context.contentResolver
            val bitmap = contentResolver.openInputStream(it)?.use { stream ->
                android.graphics.BitmapFactory.decodeStream(stream)
            }
            if (bitmap != null) {
                val result = com.mellowfilm.pro.qr.QrCodeAnalyzer.scanBitmap(bitmap)
                if (result != null) {
                    viewModel.onQrScanned(result)
                }
            }
        }
    }

    // Eagerly initialize CameraEngine so CameraX binds immediately on initial composition
    val cameraEngine = remember(context, lifecycleOwner) {
        viewModel.cameraEngine ?: CameraEngine(
            context = context,
            lifecycleOwner = lifecycleOwner,
            database = viewModel.database,
            soundManager = viewModel.soundManager,
            orientationManager = viewModel.orientationManager,
            prefs = viewModel.prefs
        ).also { viewModel.cameraEngine = it }
    }

    val vhsError by cameraEngine.vhsError.collectAsState()
    val gpuPreview by cameraEngine.filmGpuActive.collectAsState()
    val gpuError by cameraEngine.gpuPreviewError.collectAsState()
    val tapDebug by cameraEngine.tapDebug.collectAsState()
    val timingDebug by cameraEngine.timingDebug.collectAsState()
    // 現像中の枚数(0より大きい間、シャッターのリングをくるくる回す)
    val pendingCount by cameraEngine.pendingCount.collectAsState()
    // エンジン作成後に直接つなぐ(最初の描画で空の値に固定されて、起動時に小窓が空になっていた)
    val latestPhoto by cameraEngine.latestCapturedPhoto.collectAsState()
    val isPaused by cameraEngine.isPaused.collectAsState()
    val isVhs = currentMode == FilmMode.MOV_VHS

    val iconAngle = rememberIconAngle(orientation)
    val scope = rememberCoroutineScope()

    // 起動時と、アプリが前面に戻るたびに、左下の小窓の最新ファイルを読み直す
    DisposableEffect(lifecycleOwner) {
        cameraEngine.refreshLatestPhoto()
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) cameraEngine.refreshLatestPhoto()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val activity = context.findActivity()

    // シャッター: 前面カメラでフラッシュONの静止画は、画面の明るさを最大にして白く光らせてから撮り、後で元に戻す
    val onShutter: () -> Unit = {
        val isStill = currentMode != FilmMode.MOV && currentMode != FilmMode.MOV_VHS
        if (isStill && flashMode == FlashMode.ON && cameraEngine.isFrontLens) {
            // タイマーのカウント中にもう一度押したら取り消す(onShutterPressed が判断する)
            viewModel.onShutterPressed {
                scope.launch {
                    val window = activity?.window
                    val savedBrightness = window?.attributes?.screenBrightness ?: -1f
                    setScreenBrightness(window, 1f)
                    viewModel.setShutterFlash(true)
                    delay(350) // 明るさが反映されてから撮る
                    cameraEngine.takePhoto()
                    delay(350)
                    viewModel.setShutterFlash(false)
                    setScreenBrightness(window, savedBrightness) // -1 はシステム設定に戻す
                }
            }
        } else {
            viewModel.triggerShutter()
        }
    }

    // Body styling based on current mode
    val bodyColor = when (currentMode) {
        FilmMode.FUJI -> Color(0xFF14241D) // Classic QuickSnap Dark Forest Green
        FilmMode.KODA -> Color(0xFF2A2111) // FunSaver Warm Vintage Amber Brown
        FilmMode.PHOTO -> Color(0xFF121417) // Titanium Pro Camera Matte Black
        FilmMode.MOV -> Color(0xFF1C1318) // Vintage VHS Camcorder
        FilmMode.MOV_VHS -> Color(0xFF1C1318) // VHS effect mode
        FilmMode.QR -> Color(0xFF131722) // Cyber Scan Navy
        else -> Color(0xFF14241D)
    }

    val accentColor = when (currentMode) {
        FilmMode.FUJI -> Color(0xFF38A169)
        FilmMode.KODA -> Color(0xFF8E1712) // 黄色の上で見やすい濃い赤
        FilmMode.PHOTO -> Color(0xFF9C92FF)
        FilmMode.MOV -> Color(0xFFEC4899)
        FilmMode.MOV_VHS -> Color(0xFFEC4899)
        FilmMode.QR -> Color(0xFF08ADAE)
        else -> Color(0xFF38A169)
    }

    val skin = skinFor(currentMode)
    val soundEnabled by viewModel.soundEnabled.collectAsState()
    val vignetteValue by viewModel.prefs.vignette.collectAsState()
    val dateStampStyle by viewModel.prefs.dateStampStyle.collectAsState()
    val oisOn by viewModel.prefs.ois.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(skin.body)
    ) {
        // KODA: ボディに横長の赤い楕円を、プレビューの後ろの右寄りに置く。プレビューの周りだけ見える
        if (currentMode == FilmMode.KODA) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawOval(
                    color = skin.topBar,
                    // 上端はプレビューの上端に合わせ、プレビューより上にはみ出さない
                    topLeft = androidx.compose.ui.geometry.Offset(-0.10f * w, 0.10f * h),
                    size = androidx.compose.ui.geometry.Size(1.40f * w, 0.66f * h)
                )
            }
        }
        // FUJI: ボディ上部を緑にする(斜めの直線。左が低く、右が高い)。プレビューの後ろに描く
        if (currentMode == FilmMode.FUJI) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, 0.40f * h)
                    lineTo(0f, 0.71f * h)
                    close()
                }
                drawPath(path, color = skin.topBar)
            }
        }
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Retro Toolbar
            TopToolbar(
                currentMode = currentMode,
                flashMode = flashMode,
                dateStampEnabled = dateStampEnabled,
                soundEnabled = soundEnabled,
                onToggleSound = { viewModel.toggleSound() },
                accentColor = accentColor,
                skin = skin,
                onToggleLens = { viewModel.toggleLens() },
                onOpenSettings = { showSettingsDialog = true },
                onToggleDateStamp = { viewModel.toggleDateStamp() },
                iconAngle = iconAngle,
                oisAvailable = viewModel.oisAvailable,
                oisOn = oisOn,
                onToggleOis = { viewModel.toggleOis() }
            )

            // 2. Viewfinder Frame: fixed 3:4 normally, landscape 4:3 centered with black bars in VHS mode
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(if (isVhs) Color.Black else Color.Transparent)
                    .padding(
                        horizontal = if (isVhs) 0.dp else 12.dp,
                        vertical = 6.dp
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = (if (isVhs) Modifier.aspectRatio(4f / 3f)
                    else Modifier.fillMaxWidth().aspectRatio(3f / 4f))
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                        .border(2.dp, skin.finderBorder, RoundedCornerShape(8.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                val current = viewModel.cameraEngine?.zoomRatio?.value ?: 1f
                                viewModel.cameraEngine?.setZoom(current * zoom)
                            }
                        }
                        .pointerInput(Unit) {
                            // タップ位置にピント・露出を合わせる(PHOTOモードのみ有効。判定はエンジン側)
                            detectTapGestures { offset ->
                                // 反応した瞬間に一瞬バイブさせ、タップ位置に赤い印を出す(PHOTO以外・準備前は反応しない)
                                if (viewModel.cameraEngine?.focusAt(offset.x, offset.y) == true) {
                                    tapMarker = offset to ((tapMarker?.second ?: 0) + 1)
                                }
                            }
                        }
                ) {
                    // EV ±4・±5 のデジタルの明るさ(プレビューも合わせる。PHOTO のみ)
                    val previewEv by viewModel.exposureEV.collectAsState()
                    // CameraX Native Preview (High Performance SurfaceView)
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                // 色温度などの重ね塗りを映像の上に出すため、TextureView(COMPATIBLE)を使う
                                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                                scaleType = if (isWide) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
                                cameraEngine.startCamera(this) { qr ->
                                    viewModel.onQrScanned(qr)
                                }
                            }
                        },
                        // Camera binding happens only via CameraEngine (mode / lens / settings changes).
                        // Recomposition must not rebind the camera.
                        update = { previewView ->
                            previewView.scaleType = if (isWide) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
                            // 明るさの倍率が変わったときだけ、表示の色を掛け直す
                            val gain = if (currentMode == FilmMode.PHOTO) com.mellowfilm.pro.camera.DigitalExposure.gainFor(previewEv) else 1f
                            if (previewView.tag != gain) {
                                previewView.tag = gain
                                if (gain == 1f) {
                                    previewView.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
                                } else {
                                    previewView.setLayerType(
                                        android.view.View.LAYER_TYPE_HARDWARE,
                                        android.graphics.Paint().apply {
                                            colorFilter = com.mellowfilm.pro.camera.DigitalExposure.colorFilter(gain)
                                        }
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // 色温度のプレビュー(PHOTO のみ): 撮る写真と同じ係数を、映像の上に掛ける
                    val colorTempValue by viewModel.prefs.colorTemp.collectAsState()
                    if (currentMode == FilmMode.PHOTO && colorTempValue != 0) {
                        val g = com.mellowfilm.pro.camera.ColorTemp.gains(colorTempValue)
                        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(
                                color = Color(g[0], g[1], g[2], 1f),
                                blendMode = androidx.compose.ui.graphics.BlendMode.Modulate
                            )
                        }
                    }

                    // VHS live preview: GL-rendered frames (effect + OSD are burned into the recording too)
                    if (isVhs || gpuPreview) {
                      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        // VHSは4:3の映像を、ひずませずに枠いっぱいに広げる(はみ出した部分は枠で切る)。フィルムは従来どおり
                        val boxW = maxWidth
                        val boxH = maxHeight
                        // VHS(4:3の枠に合わせる)
                        val fitH = boxW * 0.75f
                        val useWidth = fitH <= boxH
                        val coverW = if (useWidth) boxW else boxH * (4f / 3f)
                        val coverH = if (useWidth) fitH else boxH
                        AndroidView(
                            factory = { ctx ->
                                val tv = TextureView(ctx)
                                tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                    override fun onSurfaceTextureAvailable(
                                        surface: SurfaceTexture, width: Int, height: Int
                                    ) {
                                        cameraEngine.attachVhsTextureView(tv)
                                    }

                                    override fun onSurfaceTextureSizeChanged(
                                        surface: SurfaceTexture, width: Int, height: Int
                                    ) {
                                    }

                                    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                        cameraEngine.attachVhsTextureView(null)
                                        return true
                                    }

                                    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                                }
                                tv
                            },
                            modifier = if (isVhs) {
                                Modifier.align(Alignment.Center).requiredSize(coverW, coverH)
                            } else {
                                Modifier.fillMaxSize()
                            }
                        )
                      }
                        (vhsError ?: gpuError)?.let { msg ->
                            Text(
                                text = msg,
                                color = Color(0xFFFFB4AB),
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .padding(16.dp)
                                    .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            )
                        }
                    }

                    // タップ位置の赤い小さい印(3秒で消える)
                    tapMarker?.let { (pos, _) ->
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(color = Color.Red, radius = 6.dp.toPx(), center = pos)
                        }
                    }


                    // タップ露出の確認表示(明るさと補正値)
                    tapDebug?.let { msg ->
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // 現像時間の表示(撮影後の数秒だけ)
                    timingDebug?.let { msg ->
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Live Filter simulation overlay (not used in VHS mode: OSD is rendered by the GL pipeline)
                    if (!isVhs && !gpuPreview) {
                        LiveFilterOverlay(
                            mode = currentMode,
                            filterSettings = filterSettings,
                            isLandscape = orientation.isLandscape,
                            hasDateStamp = dateStampEnabled,
                            vignette = vignetteValue / 100f,
                            dateStyle = dateStampStyle
                        )
                    }

                    // Shutter White Flash animation
                    androidx.compose.animation.AnimatedVisibility(
                        visible = shutterFlash,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White)
                        )
                    }

                    // タイマーのカウントダウン表示(中央に大きく)
                    if (countdown > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(120.dp)
                                .background(Color(0x99000000), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = countdown.toString(),
                                color = Color.White,
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // QR scanning reticle
                    if (currentMode == FilmMode.QR) {
                        QrReticleOverlay()
                    }

                    // Pan-Focus indicator badge
                    if (filterSettings.panFocusRestricted && (currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA)) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "過焦点固定 (<1m Bokeh / >=1m Sharp)",
                                color = Color(0xFFFFD54F),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // MOV Video live recording HUD badge (VHS shows its own REC/PLAY OSD in the picture)
                    if (currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            if (isRecording) {
                                val mins = recordingSeconds / 60
                                val secs = recordingSeconds % 60
                                Text(
                                    text = "● REC " + String.format("%02d:%02d", mins, secs),
                                    color = Color(0xFFEF4444),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = "スタンバイ ⏸ (シャッターで録画)",
                                    color = Color(0xFF34D399),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3. Icon bar under the finder (per-mode controls, see IconBar.kt)
            IconBar(
                viewModel = viewModel,
                currentMode = currentMode,
                dateStampEnabled = dateStampEnabled,
                accentColor = accentColor,
                onToggleDateStamp = { viewModel.toggleDateStamp() },
                onAdjustBarOpenChanged = { overlayBarOpen = it }
            )

            // 5. Bottom Controls (Gallery, Shutter, Multi-Import)
            val focusLocked by viewModel.focusLocked.collectAsState()
            LaunchedEffect(currentMode) { viewModel.unlockFocus() }
            BottomControlBar(
                latestPhoto = latestPhoto,
                currentMode = currentMode,
                isRecording = isRecording,
                pendingCount = pendingCount,
                recordingSeconds = recordingSeconds,
                flashMode = flashMode,
                accentColor = accentColor,
                skin = skin,
                onOpenGallery = {
                    // ギャラリーを開くときは、トーチを消しておく
                    if (flashMode == FlashMode.TORCH) viewModel.setFlash(FlashMode.OFF)
                    viewModel.setScreenState(ScreenState.GALLERY)
                },
                onTriggerShutter = onShutter,
                focusLocked = focusLocked,
                onToggleFocusLock = { viewModel.toggleFocusLock() },
                onToggleFlash = { viewModel.toggleFlash() },
                onSetFlash = { viewModel.setFlash(it) },
                onScanQrFile = { qrImagePicker.launch("image/*") },
                isMovie = currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS,
                isPaused = isPaused,
                onTogglePause = { viewModel.togglePauseRecording() },
                iconAngle = iconAngle,
                showTimer = currentMode == FilmMode.PHOTO || currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA,
                lensAvailable = currentMode == FilmMode.PHOTO && viewModel.lensInstalled,
                lensOn = lensOnState,
                onToggleLens = { viewModel.toggleGoogleLens() },
                timerOn = timerEnabled,
                timerSeconds = timerSeconds,
                onCycleTimer = { viewModel.cycleTimer() }
            )

            // 4. Mode Carousel Switcher(シャッターの行の下・一番下)
            ModeSelector(
                currentMode = currentMode,
                accentColor = accentColor,
                skin = skin,
                onSelectMode = { viewModel.onModeTabTapped(it) }
            )


            Spacer(modifier = Modifier.height(16.dp))
        }


        // FUJI・KODA: ボディの右側に、用意した画像を差し込む(位置・大きさは画面に対する割合)。
        // 画面の重ね順の一番上に置く(タッチは通す)。画像: res/drawable-nodpi/fuji_panel.png / koda_panel.png
        if (currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(
                        if (currentMode == FilmMode.FUJI) R.drawable.fuji_panel else R.drawable.koda_panel
                    ),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .offset(x = maxWidth * PANEL_X, y = maxHeight * PANEL_Y)
                        .size(width = maxWidth * PANEL_W, height = maxHeight * PANEL_H)
                        // ビネット・グレインの調整バーを開いている間は薄くする
                        .graphicsLayer { alpha = panelAlpha }
                )
            }
        }

        // Google レンズ: 撮ったあとの確認(誤操作を防ぐため、送る前に必ず聞く)
        lensPending?.let {
            var saveChecked by remember(it) { mutableStateOf(false) }
            DarkAlertDialog(
                onDismissRequest = { viewModel.cancelLens() },
                title = { Text("Googleレンズに送りますか？", fontWeight = FontWeight.Bold) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = saveChecked, onCheckedChange = { saveChecked = it })
                        Text("端末にも保存する", fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { viewModel.resolveLens(saveChecked) }) { Text("OK") }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.cancelLens() }) { Text("キャンセル") }
                }
            )
        }


        // QR Result Dialog
        scannedQr?.let { qrText ->
            DarkAlertDialog(
                onDismissRequest = { viewModel.clearQrResult() },
                title = { Text("QRコード検出") },
                text = { Text(qrText) },
                confirmButton = {
                    Button(onClick = { viewModel.clearQrResult() }) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, qrText)
                        }
                        context.startActivity(android.content.Intent.createChooser(send, "共有"))
                    }) {
                        Text("共有")
                    }
                }
            )
        }


        // Settings / Film Tweaks Dialog
        if (showSettingsDialog) {
            FilmSettingsDialog(
                settings = filterSettings,
                prefs = viewModel.prefs,
                viewModel = viewModel,
                onDismiss = { showSettingsDialog = false },
                onUpdate = { viewModel.updateFilterSettings(it) }
            )
        }
    }
}

/** トップバーの1つ分の枠。枠の幅はすべて同じなので、アイコンの数が変わっても大きさと間隔は揃う */
@Composable
private fun RowScope.ToolbarSlot(content: @Composable () -> Unit) {
    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun TopToolbar(
    currentMode: FilmMode,
    flashMode: FlashMode,
    dateStampEnabled: Boolean,
    soundEnabled: Boolean,
    onToggleSound: () -> Unit,
    accentColor: Color,
    skin: CameraSkin,
    onToggleLens: () -> Unit,
    onOpenSettings: () -> Unit,
    oisAvailable: Boolean = false,
    oisOn: Boolean = false,
    onToggleOis: () -> Unit = {},
    onToggleDateStamp: () -> Unit = {},
    iconAngle: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            // 高さは中身(アイコン)に合わせる。こうしないと、子の fillMaxHeight が画面いっぱいに広がる
            .height(IntrinsicSize.Min)
            .background(skin.topBar)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // アプリ名とモード名は、右のアイコンと同じ高さに置く。バージョンはその下
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            Row(
                modifier = Modifier.align(Alignment.CenterStart),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mellow Film",
                    fontWeight = FontWeight.Black,
                    color = skin.topText,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(accentColor, RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 1.5.dp)
                ) {
                    Text(
                        text = currentMode.id,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }
            // 新旧の混同防止用。完成したら削除する
            val versionCtx = LocalContext.current
            val versionText = remember(versionCtx) {
                runCatching { versionCtx.packageManager.getPackageInfo(versionCtx.packageName, 0).versionName }
                    .getOrNull() ?: ""
            }
            Text(
                text = "v$versionText",
                color = skin.topText.copy(alpha = 0.6f),
                fontSize = 8.sp,
                modifier = Modifier.align(Alignment.BottomStart)
            )
        }

        // Quick Controls (equal spacing)
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Front / back camera switch
            ToolbarSlot {
                IconButton(modifier = Modifier.rotate(iconAngle), onClick = onToggleLens) {
                    Icon(
                        painter = painterResource(R.drawable.ic_flip_camera),
                        contentDescription = "カメラ切替",
                        tint = skin.topIcon
                    )
                }
            }

            // Shutter sound toggle (back in the top bar)
            ToolbarSlot {
                IconButton(modifier = Modifier.rotate(iconAngle), onClick = onToggleSound) {
                    Icon(
                        imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "シャッター音",
                        tint = skin.topIcon.copy(alpha = if (soundEnabled) 1f else 0.35f)
                    )
                }
            }

            // Detailed Settings
            ToolbarSlot {
                IconButton(modifier = Modifier.rotate(iconAngle), onClick = onOpenSettings) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "設定",
                        tint = skin.topIcon
                    )
                }
            }

        }
    }
}

@Composable
fun LiveFilterOverlay(
    mode: FilmMode,
    filterSettings: FilterSettings,
    isLandscape: Boolean,
    hasDateStamp: Boolean,
    vignette: Float,
    dateStyle: DateStampStyle = DateStampStyle()
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Vignette simulation (strength from the settings screen). フィルムモード(FUJI・KODA)だけ
        val filmMode = mode == FilmMode.FUJI || mode == FilmMode.KODA
        if (vignette > 0f && filmMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        // 巨大な画像(中心が透明・周辺が黒)を、強さに応じて縮める。
                        // 強さ0では画像が画面より大きく、黒い部分は画面に入らない。強くすると縮み、黒い部分が画面の中へ入る。
                        // 形は枠の縦横比に合わせた楕円
                        val v = vignette.coerceIn(0f, 1f)
                        val k = 2.2f - 1.7f * v          // 画像の大きさ(枠の半分を1とした倍率)
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val stops = ArrayList<Pair<Float, Color>>()
                        stops.add(0f to Color.Transparent)
                        stops.add(0.75f to Color.Transparent)
                        for (i in 1..31) {
                            val t = i / 31f
                            // smootherstep: 段差が見えにくい。一番濃い黒さは一定(0.8)
                            val ease = t * t * t * (t * (t * 6f - 15f) + 10f)
                            stops.add((0.75f + 0.25f * t) to Color.Black.copy(alpha = 0.8f * ease))
                        }
                        withTransform({
                            translate(cx, cy)
                            scale(k * cx, k * cy, Offset.Zero)
                        }) {
                            // 画像の外(周辺)は、一番濃い黒さのまま
                            drawRect(
                                brush = Brush.radialGradient(
                                    colorStops = stops.toTypedArray(),
                                    center = Offset.Zero,
                                    radius = 1f
                                ),
                                topLeft = Offset(-4f, -4f),
                                size = Size(8f, 8f)
                            )
                        }
                    }
            )
        }

        // Mode-specific color tint
        when (mode) {
            FilmMode.FUJI -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x18FF5533)) // Warm reddish disposable tint
                )
            }
            FilmMode.KODA -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x15FFAA33)) // Golden amber soft gradation
                )
            }
            FilmMode.MOV, FilmMode.MOV_VHS -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x1200E5FF))
                )
            }
            else -> {}
        }

        // Live date stamp preview: same look as the saved photo (font, colours, position, opacity)
        if (hasDateStamp && (mode == FilmMode.FUJI || mode == FilmMode.KODA)) {
            val dateStr = remember { DateStampRenderer.extractDateString(null) }
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawIntoCanvas { c ->
                    // 横持ちでも位置は動かさず、左下・縦書きに固定する(案A・試験)
                    DateStampRenderer.drawStamp(c.nativeCanvas, size.width, size.height, dateStr, false, dateStyle)
                }
            }
        }
    }
}

@Composable
fun QrReticleOverlay() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(12.dp))
        )
        Text(
            text = "QRコードを枠に合わせてください",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ModeSelector(
    currentMode: FilmMode,
    accentColor: Color,
    skin: CameraSkin,
    onSelectMode: (FilmMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(skin.modeBar)
            .padding(horizontal = 6.dp, vertical = 4.dp)
            // 左右スワイプで隣のモードへ(端では止まる)
            .pointerInput(currentMode) {
                val threshold = 60.dp.toPx()
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        val tabs = listOf(FilmMode.FUJI, FilmMode.KODA, FilmMode.PHOTO, FilmMode.MOV, FilmMode.QR)
                        val idx = tabs.indexOfFirst { it == currentMode || (it == FilmMode.MOV && currentMode == FilmMode.MOV_VHS) }
                        if (idx >= 0 && kotlin.math.abs(total) > threshold) {
                                    // 右へスワイプ → 右のモード / 左へスワイプ → 左のモード(指の動きと揃える)
                            val next = if (total > 0) (idx + 1).coerceAtMost(tabs.lastIndex) else (idx - 1).coerceAtLeast(0)
                            if (next != idx) onSelectMode(tabs[next])
                        }
                    },
                    onDragCancel = { total = 0f }
                ) { _, dragAmount -> total += dragAmount }
            },
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Fixed tab order (do not change): FUJI / KODA / PHOTO / MOV / QR
        // The MOV tab also covers MOV_VHS; tapping MOV again toggles MOV <-> VHS.
        val tabs = listOf(FilmMode.FUJI, FilmMode.KODA, FilmMode.PHOTO, FilmMode.MOV, FilmMode.QR)
        tabs.forEach { mode ->
            val isMovTab = mode == FilmMode.MOV
            val isSelected = currentMode == mode || (isMovTab && currentMode == FilmMode.MOV_VHS)
            val label = if (isMovTab && currentMode == FilmMode.MOV_VHS) "VHS" else mode.id
            // 5つのタブを同じ幅にして、PHOTO(真ん中)が必ず左右の中心に来るようにする
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isSelected) skin.modeSelected else skin.modeIdle,
                fontSize = if (isSelected) 14.sp else 12.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                // 「PHOTO」が二行に折れないよう、折り返しを止めて余白を詰める
                softWrap = false,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        (if (isSelected) skin.modePill else null) ?: Color.Transparent,
                        RoundedCornerShape(16.dp)
                    )
                    .clickable { onSelectMode(mode) }
                    .padding(horizontal = 4.dp, vertical = 6.dp)
            )
            }
        }
    }
}

@Composable
fun BottomControlBar(
    latestPhoto: com.mellowfilm.pro.data.model.FilmPhoto?,
    currentMode: FilmMode,
    isRecording: Boolean = false,
    recordingSeconds: Long = 0L,
    flashMode: FlashMode,
    accentColor: Color,
    skin: CameraSkin,
    onOpenGallery: () -> Unit,
    onTriggerShutter: () -> Unit,
    focusLocked: Boolean = false,
    onToggleFocusLock: () -> Unit = {},
    onToggleFlash: () -> Unit,
    onSetFlash: (FlashMode) -> Unit = {},
    iconAngle: Float = 0f,
    onScanQrFile: () -> Unit,
    isMovie: Boolean = false,
    isPaused: Boolean = false,
    pendingCount: Int = 0,
    onTogglePause: () -> Unit = {},
    showTimer: Boolean = false,
    lensAvailable: Boolean = false,
    lensOn: Boolean = false,
    onToggleLens: () -> Unit = {},
    timerOn: Boolean = false,
    timerSeconds: Int = 3,
    onCycleTimer: () -> Unit = {}
) {
    // Shutter sits at the true horizontal center; gallery (left) and flash (right) are pinned to the edges
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(84.dp)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // 画面の幅から、小窓(左端 54dp)とシャッター(中央 ±38dp)の間の中央を計算する
        val maxW = maxWidth
        // Left: Developed Film Gallery Thumbnail
        Box(
            modifier = Modifier
                .size(54.dp)
                // 外側は枠の色で塗り、その内側に背景を重ねる。ボディ色が縁に滲んで見えないようにする
                .drawBehind {
                    val bw = 1.5.dp.toPx()
                    drawRoundRect(
                        color = skin.ring,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx())
                    )
                    drawRoundRect(
                        brush = skin.buttonFill,
                        topLeft = Offset(bw, bw),
                        size = androidx.compose.ui.geometry.Size(size.width - 2 * bw, size.height - 2 * bw),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx() - bw)
                    )
                }
                .align(Alignment.CenterStart)
                .clickable(onClick = onOpenGallery),
            contentAlignment = Alignment.Center
        ) {
            if (latestPhoto != null) {
                AsyncImage(
                    model = Uri.parse(latestPhoto.uriString),
                    contentDescription = "現像アルバム",
                    modifier = Modifier.fillMaxSize().padding(1.5.dp).clip(RoundedCornerShape(8.5.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = Color(0xFF888277),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Center: Shutter / Video Record Button
        run {
            // Retro Film Winding Shutter Button / Video Record Button
            val shutterRing = if ((currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) && isRecording) Color(0xFFEF4444) else skin.ring
            // FUJI・KODA は、黒系のリアルな質感のボタン(縁・面・反射・影はそのまま Canvas で描く)
            val knob = currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA
            Box(
                modifier = Modifier
                    .size(76.dp)
                    // 外側は枠の色で塗り、その内側に背景を重ねる(ボディ色の縁の滲みを防ぐ)
                    .drawBehind {
                        if (!knob) {
                            drawCircle(color = shutterRing, radius = size.minDimension / 2f)
                            drawCircle(color = skin.shutterCore, radius = size.minDimension / 2f - 3.dp.toPx())
                        }
                    }
                    .clickable {
                        if (currentMode == FilmMode.QR) {
                            onScanQrFile()
                        } else {
                            onTriggerShutter()
                        }
                    }
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                if (currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) {
                    if (isRecording) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFEF4444))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Color(0xFFE11D48))
                                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                        }
                    }
                } else if (currentMode == FilmMode.QR) {
                    Icon(
                        painter = painterResource(R.drawable.ic_qr_code_add),
                        contentDescription = "QRスキャン",
                        // White icon on the bright shutter fill
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                } else if (knob) {
                    // 黒系のリアルな質感(縁の金属・面のくぼみ・上の反射・周りの影)
                    Canvas(modifier = Modifier.requiredSize(76.dp)) {
                        drawKnob()
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(skin.shutterCore)
                            .border(2.dp, skin.ring, CircleShape)
                    )
                }

                // 現像中: リングをくるくる回す(シャッターは押せたままで、枚数が0になると止まって元に戻る)
                if (pendingCount > 0) {
                    CircularProgressIndicator(
                        modifier = Modifier.matchParentSize(),
                        color = Color.White,
                        strokeWidth = 3.dp
                    )
                }
            }

            // Pause / resume button: small, right of the shutter, only while recording a movie
            if (isMovie && isRecording) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(x = 62.dp)
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(skin.buttonFill, CircleShape)
                        .border(1.5.dp, skin.ring, CircleShape)
                        .clickable(onClick = onTogglePause),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isPaused) "再開" else "一時停止",
                        tint = skin.buttonIcon,
                        modifier = Modifier.size(18.dp).rotate(iconAngle)
                    )
                }
            }

            // Google レンズ(PHOTO のみ・対応アプリがあるときだけ): アイコンだけ。シャッターと小窓の、ちょうど中心。オフのときは半透明
            // 鍵(ピント固定・静止画のみ): シャッターの右。押すと今のピントで固定、もう一度押すと解除
            if (currentMode == FilmMode.PHOTO || currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(x = (maxW / 4f) - 8.dp)
                        .size(36.dp)
                        .clickable(onClick = onToggleFocusLock),
                    contentAlignment = Alignment.Center
                ) {
                    MaterialSymbol(
                        name = if (focusLocked) "lock" else "lock_open",
                        tint = if (focusLocked) Color(0xFFF5B82E) else Color.White.copy(alpha = 0.35f),
                        size = 24.dp
                    )
                }
            }

            if (lensAvailable) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        // 小窓の右端(54dp)とシャッターの左端(中央-38dp)の中点へ
                        .offset(x = -(maxW / 4f) + 8.dp)
                        .size(36.dp)
                        .clickable(onClick = onToggleLens),
                    contentAlignment = Alignment.Center
                ) {
                    MaterialSymbol(
                        name = "image_search",
                        tint = if (lensOn) Color(0xFFF5B82E) else Color.White.copy(alpha = 0.35f),
                        size = 24.dp,
                        modifier = Modifier.rotate(iconAngle)
                    )
                }
            }
            // Google レンズのボタンは、シャッターと小窓の間へ戻した
            // Flash button (right edge): 押すとメニュー(トーチ・オン)が上へスライドして出る。
            // オン/トーチのときに押すとオフに戻る。枠・背景なし、アイコンと文字だけ
            // フラッシュ(右端): 左は飾りのオフのアイコン(押せない)、右にスイッチ2つ(上がオン、下がトーチ)。
            // どちらか一方だけ選べる。選んだスイッチをもう一度押すとオフ。切り替えはスイッチだけで行う
            val bright = currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA
            // MOV・VHS・QR はトーチだけ(フラッシュのスイッチは出さない)
            val torchOnly = currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS || currentMode == FilmMode.QR
            Row(
                modifier = Modifier.align(Alignment.CenterEnd).offset(x = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!torchOnly) FlashSwitchRow(
                        iconContent = { tint, size, mod ->
                            Icon(imageVector = Icons.Default.FlashOn, contentDescription = "オン", tint = tint, modifier = mod.size(size))
                        },
                        label = "オン",
                        on = flashMode == FlashMode.ON,
                        bright = bright,
                        iconAngle = iconAngle,
                        onClick = {
                            onSetFlash(if (flashMode == FlashMode.ON) FlashMode.OFF else FlashMode.ON)
                        }
                    )
                    FlashSwitchRow(
                        iconContent = { tint, size, mod ->
                            Icon(painter = painterResource(R.drawable.ic_flashlight), contentDescription = "TORCH", tint = tint, modifier = mod.size(size))
                        },
                        label = "トーチ",
                        on = flashMode == FlashMode.TORCH,
                        bright = bright,
                        iconAngle = iconAngle,
                        onClick = {
                            onSetFlash(if (flashMode == FlashMode.TORCH) FlashMode.OFF else FlashMode.TORCH)
                        }
                    )
                }
            }
        }
    }
}

/** フラッシュの状態に応じた色(オン・トーチは黄色の点灯、オフは白の35%) */
private fun flashTint(mode: FlashMode, bright: Boolean): Color = when {
    mode != FlashMode.OFF -> Color(0xFFFFD54F)
    bright -> Color.White
    else -> Color.White.copy(alpha = 0.35f)
}

private fun flashIcon(mode: FlashMode): ImageVector = when (mode) {
    FlashMode.OFF -> Icons.Default.FlashOff
    FlashMode.ON -> Icons.Default.FlashOn
    FlashMode.TORCH -> Icons.Default.FlashlightOn
}

private fun flashLabel(mode: FlashMode): String = when (mode) {
    FlashMode.OFF -> "OFF"
    FlashMode.ON -> "ON"
    FlashMode.TORCH -> "TORCH"
}

/** トグルスイッチ1つ(黒いベース。点灯した方のつまみが黄色、横にアイコン) */
@Composable
private fun FlashSwitchRow(
    iconContent: @Composable (tint: Color, size: Dp, modifier: Modifier) -> Unit,
    label: String,
    on: Boolean,
    bright: Boolean,
    iconAngle: Float,
    onClick: () -> Unit
) {
    val knobBias by animateFloatAsState(
        targetValue = if (on) 1f else -1f,
        animationSpec = tween(durationMillis = 180),
        label = "flashKnob"
    )
    val iconTint = if (on) Color(0xFFFFD54F) else flashTint(FlashMode.OFF, bright)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (bright) {
            // FUJI・KODA: 黒い溝と、3本線の入ったつまみ
            Box(
                modifier = Modifier
                    .size(width = 42.dp, height = 16.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF0D0D0D), RoundedCornerShape(3.dp))
                    .border(1.dp, Color(0xFF1E1E1E), RoundedCornerShape(3.dp))
                    .clickable(onClick = onClick)
                    .padding(1.dp),
                contentAlignment = BiasAlignment(knobBias, 0f)
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 21.dp, height = 14.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF505050), RoundedCornerShape(2.dp))
                        .border(1.dp, Color(0xFF666666), RoundedCornerShape(2.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        repeat(3) {
                            Box(
                                modifier = Modifier
                                    .size(width = 1.dp, height = 6.dp)
                                    .clip(RoundedCornerShape(1.dp))
                                    .background(Color(0xFF0A0A0A))
                            )
                        }
                    }
                }
            }
        } else {
            // その他: 細い棒と、灰色の輪のつまみ。オンではつまみが右へ動くだけ
            Box(
                modifier = Modifier
                    .size(width = 36.dp, height = 16.dp)
                    .clickable(onClick = onClick),
                contentAlignment = BiasAlignment(knobBias, 0f)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(width = 28.dp, height = 3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF4D4D4D), RoundedCornerShape(2.dp))
                )
                Box(
                    modifier = Modifier
                        .size(15.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF333333), CircleShape)
                        .border(2.dp, Color(0xFF888888), CircleShape)
                )
            }
        }
        Spacer(modifier = Modifier.width(3.dp))
        iconContent(iconTint, 21.dp, Modifier.rotate(iconAngle))
    }
}

/**
 * タイマー撮影の設定ポップアップ。ラジオボタンで 3秒 / 5秒 / 10秒 / オフ を選び、OKで確定する。
 * 値は null = オフ。
 */
@Composable
fun TimerDialog(
    enabled: Boolean,
    seconds: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int?) -> Unit
) {
    // 今の設定を初期値にする(オフ中は直前の秒数=初期値 3 秒を選んだ状態にする)
    var selected by remember { mutableStateOf<Int?>(if (enabled) seconds else null) }
    val options: List<Pair<Int?, String>> = listOf(3 to "3秒", 5 to "5秒", 10 to "10秒", null to "オフ")

    DarkAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("タイマー撮影", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selected = value }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected == value, onClick = { selected = value })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, fontSize = 15.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selected) }) { Text("OK", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("キャンセル") }
        }
    )
}

/** 設定画面の1行分の選択肢(選択中は黄色の丸いチップ) */
@Composable
fun <T> PresetRow(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(
            modifier = Modifier
                .padding(top = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEach { (value, label) ->
                val on = value == selected
                Text(
                    text = label,
                    softWrap = false,
                    color = if (on) Color.Black else Color(0xFF444444),
                    fontSize = 12.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .background(
                            if (on) Color(0xFFF5B82E) else Color(0xFFE5E5E5),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelect(value) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

/** LUTを、開いたときの値へ戻す(キャンセル用) */
private fun restoreLut(viewModel: MellowFilmViewModel, mode: FilmMode, old: String?) {
    if (viewModel.prefs.lutUri(mode) == old) return
    if (old == null) viewModel.clearLut(mode) else viewModel.setLut(mode, Uri.parse(old))
}

@Composable
fun FilmSettingsDialog(
    settings: FilterSettings,
    prefs: AppPrefs,
    viewModel: MellowFilmViewModel,
    onDismiss: () -> Unit,
    onUpdate: (FilterSettings) -> Unit
) {
    var panFocus by remember { mutableStateOf(settings.panFocusRestricted) }
    var showCameraInfo by remember { mutableStateOf(false) }
    // 開いたときの値(「キャンセル」で戻す)
    val snapMirror = remember { viewModel.prefs.mirrorFront.value }
    val snapOis = remember { viewModel.prefs.ois.value }
    val snapGpu = remember { viewModel.prefs.gpuFilm.value }
    val snapStamp = remember { viewModel.dateStampEnabled.value }
    val snapStyle = remember { viewModel.prefs.dateStampStyle.value }
    val snapLutFuji = remember { viewModel.prefs.lutUri(FilmMode.FUJI) }
    val snapLutKoda = remember { viewModel.prefs.lutUri(FilmMode.KODA) }
    // 保存して閉じる(外側を触る・戻るボタンでも保存する)
    fun saveAndClose() {
        onUpdate(settings.copy(panFocusRestricted = panFocus))
        onDismiss()
    }
    // キャンセル: 開いたときの値に戻して閉じる(保存しない)
    fun cancelAndClose() {
        val p = viewModel.prefs
        val oisChanged = p.ois.value != snapOis
        val gpuChanged = p.gpuFilm.value != snapGpu
        p.setMirrorFront(snapMirror)
        p.setOis(snapOis)
        p.setGpuFilm(snapGpu)
        p.setDateStampStyle(snapStyle)
        if (viewModel.dateStampEnabled.value != snapStamp) viewModel.toggleDateStamp()
        restoreLut(viewModel, FilmMode.FUJI, snapLutFuji)
        restoreLut(viewModel, FilmMode.KODA, snapLutKoda)
        if (oisChanged) viewModel.cameraEngine?.applyHardwareControls()
        if (gpuChanged) viewModel.cameraEngine?.reapplyCamera()
        onDismiss()
    }

    DarkAlertDialog(
        onDismissRequest = { saveAndClose() },
        title = { Text("詳細設定", fontWeight = FontWeight.Bold) },
        text = {
            val scrollState = rememberScrollState()
            var viewportPx by remember { mutableStateOf(0) }
            Column {
            Box(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .onSizeChanged { viewportPx = it.height }
            ) {
            Column(
                modifier = Modifier
                    .verticalScroll(scrollState)
                    .padding(end = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("過焦点パンフォーカス", fontWeight = FontWeight.Bold)
                        Text("1m未満ボケ / 1m以上ピント固定", fontSize = 11.sp, color = Color.Gray)
                    }
                    MellowSwitch(checked = panFocus, onCheckedChange = { panFocus = it })
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 手ブレ補正(光学式)。見出しの下に小さく注意書き
                val oisOn by viewModel.prefs.ois.collectAsState()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("手ブレ補正", fontWeight = FontWeight.Bold)
                        Text("効果は機種によって異なります", fontSize = 11.sp, color = Color.Gray)
                    }
                    MellowSwitch(checked = oisOn, onCheckedChange = { viewModel.toggleOis() })
                }

                Spacer(modifier = Modifier.height(10.dp))

                // インカメラの左右反転(PHOTOのみ。保存する写真だけ反転し、プレビューは反転しない)
                val mirrorOn by prefs.mirrorFront.collectAsState()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("インカメラを反転させる（PHOTOモードのみ）", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    MellowSwitch(checked = mirrorOn, onCheckedChange = { prefs.setMirrorFront(it) })
                }

                Spacer(modifier = Modifier.height(10.dp))


                ProcessingSettings(viewModel = viewModel)

                Spacer(modifier = Modifier.height(16.dp))

            }

            // Simple scrollbar: thumb size and position follow the scroll state
            if (scrollState.maxValue > 0 && viewportPx > 0) {
                val density = LocalDensity.current
                val contentPx = viewportPx + scrollState.maxValue
                val thumbPx = (viewportPx.toFloat() * viewportPx / contentPx).toInt().coerceAtLeast(24)
                val offsetPx = ((viewportPx - thumbPx) * scrollState.value.toFloat() / scrollState.maxValue).toInt()
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset { IntOffset(0, offsetPx) }
                        .width(4.dp)
                        .height(with(density) { thumbPx.toDp() })
                        .background(Color(0xFF888888), RoundedCornerShape(2.dp))
                )
            }
            }
            // 閉じる・適用(右寄せ)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { cancelAndClose() }) {
                    Text("キャンセル", color = DarkDialogText)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { saveAndClose() }) {
                    Text("保存して閉じる")
                }
            }
            // 「カメラ情報」: 適用ボタンの下で右寄せ
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = { showCameraInfo = true },
                    modifier = Modifier.height(32.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) {
                    Text("カメラ情報", color = DarkDialogText)
                }
            }
            }
        },
        confirmButton = {}
    )

    // 端末のカメラ情報(マクロ対応の確認用)
    if (showCameraInfo) {
        val ctx = LocalContext.current
        val info = remember { com.mellowfilm.pro.camera.CameraInfo.describe(ctx) }
        DarkAlertDialog(
            onDismissRequest = { showCameraInfo = false },
            title = { Text("カメラ情報", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(info, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = {
                TextButton(onClick = { showCameraInfo = false }) {
                    Text("閉じる", color = DarkDialogText)
                }
            }
        )
    }
}

/** Context から Activity を探す(画面の明るさを変えるために使う) */
private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is android.content.ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** この画面だけの明るさを変える。-1 でシステム設定に戻る */
private fun setScreenBrightness(window: android.view.Window?, value: Float) {
    window ?: return
    val attrs = window.attributes
    attrs.screenBrightness = value
    window.attributes = attrs
}

/**
 * FUJI・KODA のシャッター(黒系のリアルな質感)。枠の中心に合わせて描く。アイコンは描かない。
 * 重ね順: 周りの影 → 金属の縁 → 黒い溝 → くぼんだ面 → 上の縁の反射
 */
private fun DrawScope.drawKnob() {
    val c = Offset(size.width / 2f, size.height / 2f)
    val r = size.minDimension / 2f
    val rimR = r * 0.9f                 // 外側の輪の半径
    val faceR = rimR - r * 0.06f        // 面の半径(輪との間に暗い溝が残る)
    val k = r * 0.035f                  // 三日月の厚み(中央で約 k×√2)
    val tl = Offset(c.x - r, c.y - r)
    val br = Offset(c.x + r, c.y + r)

    // 外側の輪: 暗い金属(外側の明るい縁はなし。周りのシャドウもなし)
    drawCircle(
        brush = Brush.linearGradient(listOf(Color(0xFF2E2E2E), Color(0xFF0A0A0A)), start = tl, end = br),
        radius = rimR,
        center = c
    )
    // 面: 左上が暗く、右下へいくほど明るい斜めのグラデーション
    drawCircle(
        brush = Brush.linearGradient(listOf(Color(0xFF141414), Color(0xFF3A3A3A), Color(0xFF5A5A5A)), start = tl, end = br),
        radius = faceR,
        center = c
    )
    // 内側の縁の光沢: 左上(8時〜13時)の、両端へ細くなる三日月
    drawCrescent(c, faceR, Offset(k, k), Brush.linearGradient(listOf(Color(0xFFBDBDBD), Color(0xFF6A6A6A)), start = tl, end = br))
    // 内側の縁の影: 右下(2時〜7時)の、両端へ細くなる暗い三日月
    drawCrescent(c, faceR, Offset(-k, -k), SolidColor(Color(0xFF040404)))
}

/** 角度を 0〜360 度に直す */
private fun normalizeDeg(x: Float): Float = ((x % 360f) + 360f) % 360f

/** from から to まで、through を通るように回す角度(度)。時計回りが正 */
private fun sweepThrough(from: Float, to: Float, through: Float): Float {
    val s = normalizeDeg(to - from)
    val t = normalizeDeg(through - from)
    return if (t < s) s else s - 360f
}

/**
 * 円 C1(中心 c・半径 R)から、円 C2(中心 c+shift・同じ半径)を引いた三日月を塗る。
 * 三日月は shift の反対側に出て、両端は2つの円が交わる点で細くなる。
 */
private fun DrawScope.drawCrescent(c: Offset, radius: Float, shift: Offset, brush: Brush) {
    val d = shift.getDistance()
    if (d <= 0f) return
    val c2 = c + shift
    val mid = c + shift / 2f
    val h = kotlin.math.sqrt(radius * radius - (d / 2f) * (d / 2f))
    val u = Offset(-shift.y / d, shift.x / d)
    val pA = mid + u * h
    val pB = mid - u * h
    // 三日月の中心方向(shift の反対側)の角度
    val through = Math.toDegrees(kotlin.math.atan2(-shift.y, -shift.x).toDouble()).toFloat()

    fun angle(p: Offset, center: Offset): Float =
        Math.toDegrees(kotlin.math.atan2(p.y - center.y, p.x - center.x).toDouble()).toFloat()

    val a1 = angle(pA, c)
    val sweep1 = sweepThrough(a1, angle(pB, c), through)
    val a2 = angle(pB, c2)
    val sweep2 = sweepThrough(a2, angle(pA, c2), through)

    val path = androidx.compose.ui.graphics.Path().apply {
        moveTo(pA.x, pA.y)
        arcTo(
            androidx.compose.ui.geometry.Rect(c.x - radius, c.y - radius, c.x + radius, c.y + radius),
            a1, sweep1, false
        )
        arcTo(
            androidx.compose.ui.geometry.Rect(c2.x - radius, c2.y - radius, c2.x + radius, c2.y + radius),
            a2, sweep2, false
        )
        close()
    }
    drawPath(path, brush = brush)
}

// FUJI・KODA の差し込み画像の位置と大きさ(画面の幅・高さに対する割合)。
// 実機で位置を見て、ここを調整する(仮の値)
private const val PANEL_X = 0.63f
private const val PANEL_Y = 0.64f
private const val PANEL_W = 0.34f
private const val PANEL_H = 0.22f

/** 取り込み確認の選択肢の1行(チェックボックスと文字。押すと切り替わる) */
@Composable
private fun BatchOptionRow(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    modifier: Modifier = Modifier.fillMaxWidth(),
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null, enabled = enabled)
        // チェックボックスと文字の間は、文字1つ分(13sp)あける
        Spacer(modifier = Modifier.width(13.dp))
        Text(
            text = label,
            fontSize = 13.sp,
            color = if (enabled) DarkDialogText else Color.White.copy(alpha = 0.35f)
        )
    }
}
