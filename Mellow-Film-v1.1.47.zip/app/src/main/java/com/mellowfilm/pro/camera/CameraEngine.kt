package com.mellowfilm.pro.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Environment
import android.util.Size
import android.view.Surface
import android.view.TextureView
import androidx.camera.core.SurfaceRequest
import androidx.camera.core.UseCaseGroup
import androidx.camera.video.FallbackStrategy
import com.mellowfilm.pro.vhs.VhsEffect
import com.mellowfilm.pro.vhs.VhsGlProcessor
import com.mellowfilm.pro.vhs.VhsOsdState
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.VideoCapture
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.mellowfilm.pro.data.local.FilmDatabase
import com.mellowfilm.pro.data.prefs.AppPrefs
import com.mellowfilm.pro.data.prefs.VideoAspect
import com.mellowfilm.pro.data.prefs.VideoQuality
import com.mellowfilm.pro.data.sync.FolderSync
import android.content.ContentValues
import android.provider.MediaStore
import androidx.camera.video.MediaStoreOutputOptions
import com.mellowfilm.pro.data.model.FilmPhoto
import com.mellowfilm.pro.filter.DateStampRenderer
import com.mellowfilm.pro.filter.FilmEffect
import com.mellowfilm.pro.filter.FilmGlProcessor
import com.mellowfilm.pro.filter.FilmGlSettings
import com.mellowfilm.pro.filter.FilmMode
import com.mellowfilm.pro.filter.FilterSettings
import com.mellowfilm.pro.filter.DateStampStyle
import com.mellowfilm.pro.filter.ImageProcessor
import com.mellowfilm.pro.lut.LutRepository
import com.mellowfilm.pro.qr.QrCodeAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

enum class FlashMode {
    OFF, ON, TORCH
}

/** FUJI/KODA のGPUライブプレビュー。画像の崩れを直すまで false(撮影の GPU 加工は別スイッチで有効) */
private const val GPU_LIVE_PREVIEW = true

class CameraEngine(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val database: FilmDatabase,
    private val soundManager: SoundManager,
    private val orientationManager: OrientationManager,
    private val prefs: AppPrefs
) {
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var preview: Preview? = null
    private var imageAnalysis: ImageAnalysis? = null

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    /** 現像中の枚数。シャッターのリングの回転に使う。0 になったら止まる */
    private val _pendingCount = MutableStateFlow(0)
    val pendingCount: StateFlow<Int> = _pendingCount.asStateFlow()

    /** 直近の現像時間の表示(読込・加工・保存 ms)。数秒後に消す */
    private val _timingDebug = MutableStateFlow<String?>(null)
    val timingDebug: StateFlow<String?> = _timingDebug.asStateFlow()

    @Synchronized
    private fun beginCapture() {
        _pendingCount.value = _pendingCount.value + 1
        _isCapturing.value = true
    }

    @Synchronized
    private fun endCapture() {
        _pendingCount.value = (_pendingCount.value - 1).coerceAtLeast(0)
        if (_pendingCount.value == 0) _isCapturing.value = false
    }

    private val _zoomRatio = MutableStateFlow(1f)
    val zoomRatio: StateFlow<Float> = _zoomRatio.asStateFlow()

    private val _latestCapturedPhoto = MutableStateFlow<FilmPhoto?>(null)
    val latestCapturedPhoto: StateFlow<FilmPhoto?> = _latestCapturedPhoto.asStateFlow()

    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()
    private val _recordingSeconds = MutableStateFlow(0L)
    val recordingSeconds: StateFlow<Long> = _recordingSeconds.asStateFlow()

    private var cachedPreviewView: PreviewView? = null
    private var cachedQrCallback: ((String) -> Unit)? = null

    private var currentMode: FilmMode = FilmMode.PHOTO
    private var filterSettings = FilterSettings()
    private var hasDateStamp = true
    private var shutterSoundEnabled = prefs.shutterSound.value
    private var flashMode = FlashMode.OFF
    private var exposureIndex = 0

    /** PHOTOモードのタップAF/AE: タップ後に連続AFへ戻すまでの時間(ミリ秒) */
    private val AF_RESUME_MS = 3000L

    /** タップ露出: 目標の明るさ(0-255。中間グレー付近)/ 明るさから光量への換算のガンマ / 補正の上限(EV) */
    private val TAP_TARGET_LUMA = 118.0
    private val TAP_GAMMA = 1.1 // 補正量を約半分にする(前版は 2.2)
    private val TAP_MAX_EV = 2.0

    /** タップ位置の明るさによる露出補正(補正インデックス)。AF_RESUME_MS 後に 0 へ戻す */
    private var tapExposureIndex = 0

    /** タップ露出の確認用の表示(明るさと補正値)。AF_RESUME_MS 後に消す */
    private val _tapDebug = MutableStateFlow<String?>(null)
    val tapDebug: StateFlow<String?> = _tapDebug.asStateFlow()

    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val clearTimingRunnable = Runnable { _timingDebug.value = null }
    private val resumeAfterTapRunnable = Runnable {
        tapExposureIndex = 0
        _tapDebug.value = null
        applyHardwareControls()
    }

    /** 解析フレームの明るさ(Yプレーン)。PHOTOモードのタップ露出判定に使う */
    @Volatile private var lumaFrame: ByteArray? = null
    @Volatile private var lumaW = 0
    @Volatile private var lumaH = 0
    private val lumaAnalyzer = ImageAnalysis.Analyzer { image ->
        try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val w = image.width
            val h = image.height
            val stride = plane.rowStride
            val pixel = plane.pixelStride
            val out = ByteArray(w * h)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    out[y * w + x] = buf.get(y * stride + x * pixel)
                }
            }
            lumaFrame = out
            lumaW = w
            lumaH = h
        } catch (_: Throwable) {
        } finally {
            image.close()
        }
    }
    private var lensFacing = CameraSelector.LENS_FACING_BACK

    /** 標準動画(MOV)の映像比率。VHSは常に4:3 */
    private fun standardAspect(): Int {
        return if (currentMode == FilmMode.MOV && prefs.videoAspect.value == VideoAspect.WIDE_16_9) {
            AspectRatio.RATIO_16_9
        } else {
            AspectRatio.RATIO_4_3
        }
    }

    // VHS pipeline (GL effect applied to both preview and recording)
    private var vhsProcessor: VhsGlProcessor? = null
    private var vhsTextureView: TextureView? = null
    private var pendingVhsRequest: SurfaceRequest? = null
    private val _vhsError = MutableStateFlow<String?>(null)
    // FUJI/KODA の GPU プレビュー(有効中は UI が TextureView を出し、CPU の重ね表示を止める)
    private val _filmGpuActive = MutableStateFlow(false)
    val filmGpuActive: StateFlow<Boolean> = _filmGpuActive.asStateFlow()
    private val _gpuPreviewError = MutableStateFlow<String?>(null)
    private val _filmDebug = MutableStateFlow("")
    val filmDebug: StateFlow<String> = _filmDebug.asStateFlow()
    val gpuPreviewError: StateFlow<String?> = _gpuPreviewError.asStateFlow()
    private var filmProcessor: FilmGlProcessor? = null
    private var filmGpuFallback = false
    private var brokenRebinds = 0
    val vhsError: StateFlow<String?> = _vhsError.asStateFlow()

    init {
        refreshLatestPhoto()
    }

    /** DCIM/MellowFilm を正として DB を揃え、左下の小窓に出す最新の1件を読み直す(起動時・画面再表示時) */
    fun refreshLatestPhoto() {
        scope.launch {
            val latest = withContext(Dispatchers.IO) {
                try {
                    FolderSync.sync(context, database)
                } catch (_: Exception) {
                }
                database.filmPhotoDao().getLatestPhoto()
            }
            if (latest != null) {
                _latestCapturedPhoto.value = latest
            }
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    fun startCamera(
        previewView: PreviewView,
        onQrScanned: ((String) -> Unit)? = null
    ) {
        cachedPreviewView = previewView
        cachedQrCallback = onQrScanned

        // カメラ権限がまだなら何もしない(許可されたら MainActivity から組み直す)
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindPreviewUseCases(previewView, onQrScanned)
        }, ContextCompat.getMainExecutor(context))
    }

    /** プレビュー・撮影を組む(VHS・フィルム・PHOTO・QR) */
    private fun bindPreviewUseCases(previewView: PreviewView, onQrScanned: ((String) -> Unit)?) {
            // VHS mode: dedicated GL pipeline (preview + recording share the same shader pass).
            // Every other mode bypasses the shader completely.
            if (currentMode == FilmMode.MOV_VHS) {
                bindVhsPipeline()
                return
            }
            // FUJI/KODA with GPU preview: Preview + capture + GL effect (falls back to CPU on error)
            if (currentMode != FilmMode.FUJI && currentMode != FilmMode.KODA) filmGpuFallback = false
            if (isGpuFilmMode() && !filmGpuFallback) {
                bindFilmPipeline()
                return
            }
            _filmGpuActive.value = false
            pendingVhsRequest?.willNotProvideSurface()
            pendingVhsRequest = null

            // マクロ用の物理カメラ(PHOTOでマクロオンのとき)。全ての使うカメラに同じIDを指定する
            val physId = macroCameraIdForPhoto()

            // 3:4 target aspect ratio
            val previewBuilder = Preview.Builder().setTargetAspectRatio(standardAspect())
            if (physId != null) Camera2Interop.Extender(previewBuilder).setPhysicalCameraId(physId)
            preview = previewBuilder.build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            // Zero Shutter Lag capture for rapid continuous shooting
            val captureBuilder = ImageCapture.Builder()
                .setCaptureMode(androidx.camera.core.ImageCapture.CAPTURE_MODE_ZERO_SHUTTER_LAG)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            if (physId != null) Camera2Interop.Extender(captureBuilder).setPhysicalCameraId(physId)
            imageCapture = captureBuilder.build()

            // Video recording setup for MOV mode
            if (currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) {
                val recorder = buildRecorder(prefs.videoQuality.value, standardAspect())
                videoCapture = VideoCapture.withOutput(recorder)
            } else {
                videoCapture = null
            }

            // QR analysis if in QR mode
            if (currentMode == FilmMode.QR && onQrScanned != null) {
                imageAnalysis = ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, QrCodeAnalyzer(onQrScanned))
                    }
            } else if (currentMode == FilmMode.PHOTO) {
                // タップAE用に明るさを取る(画像は使わない)
                val analysisBuilder = ImageAnalysis.Builder()
                    .setTargetResolution(Size(320, 240))
                    // 解析画像を、画面(縦持ち基準)と同じ向きにそろえる。タップ位置の対応をずらさないため
                    .setOutputImageRotationEnabled(true)
                    .setTargetRotation(Surface.ROTATION_0)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                if (physId != null) Camera2Interop.Extender(analysisBuilder).setPhysicalCameraId(physId)
                imageAnalysis = analysisBuilder.build()
                    .also {
                        it.setAnalyzer(cameraExecutor, lumaAnalyzer)
                    }
            } else {
                imageAnalysis = null
            }

            val cameraSelector = if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            try {
                cameraProvider?.unbindAll()
                camera = if ((currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) && videoCapture != null) {
                    cameraProvider?.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        videoCapture
                    )
                } else if (imageAnalysis != null) {
                    cameraProvider?.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageCapture,
                        imageAnalysis
                    )
                } else {
                    cameraProvider?.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageCapture
                    )
                }

                // Apply initial hardware parameters (Pan-focus hyperfocal distance & flash)
                applyHardwareControls()
            } catch (_: Exception) {}
    }

    /**
     * Applies Camera2 hardware controls:
     * - Fixed focus distance (Hyperfocal distance: <1m soft, >=1m sharp)
     * - Flash mode / Torch
     * - Exposure compensation
     */
    @SuppressLint("UnsafeOptInUsageError")
    fun applyHardwareControls() {
        val cam = camera ?: return
        val camControl = cam.cameraControl
        val camInfo = cam.cameraInfo

        val camera2Control = Camera2CameraControl.from(camControl)
        val camera2Info = Camera2CameraInfo.from(camInfo)

        val optionsBuilder = CaptureRequestOptions.Builder()

        // 1. Pan-focus (Hyperfocal distance for disposable cameras)
        if (filterSettings.panFocusRestricted && (currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA)) {
            // Check minimum focus distance
            val minFocusDistance = camera2Info.getCameraCharacteristic(
                CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE
            ) ?: 0f

            if (minFocusDistance > 0f) {
                // Fixed focus at ~1.2 meters (approx 0.83 diopters)
                // Objects closer than 1m are gently out of focus; objects >=1m to infinity remain sharp
                optionsBuilder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF
                )
                optionsBuilder.setCaptureRequestOption(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    0.83f
                )
            }
        } else {
            // Standard continuous autofocus for PHOTO mode
            optionsBuilder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
        }

        // 手ブレ補正(光学式・PHOTO のみ)。対応していない端末では何もしない
        if (currentMode == FilmMode.PHOTO) {
            val oisModes = camera2Info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            if (oisModes != null && oisModes.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)) {
                optionsBuilder.setCaptureRequestOption(
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    if (prefs.ois.value) CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                    else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
                )
            }
        }

        camera2Control.setCaptureRequestOptions(optionsBuilder.build())

        // 2. Flash / Torch
        when (flashMode) {
            FlashMode.TORCH -> camControl.enableTorch(true)
            FlashMode.ON -> {
                camControl.enableTorch(false)
                imageCapture?.flashMode = ImageCapture.FLASH_MODE_ON
            }
            FlashMode.OFF -> {
                camControl.enableTorch(false)
                imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
            }
        }

        // 3. Exposure Compensation
        // タップ位置による補正(tapExposureIndex)を足し、端末の補正範囲に収める
        val range = camInfo.exposureState.exposureCompensationRange
        // EV(-5〜+5)を端末の補正範囲いっぱいに割り振る(+5 で端末の上限、-5 で下限)。以前は -5〜+5 をそのまま補正値にしていた
        val evScaled = if (exposureIndex >= 0) exposureIndex * range.upper / 3f else exposureIndex * (-range.lower) / 3f
        val evIndex = Math.round(evScaled)
        camControl.setExposureCompensationIndex((evIndex + tapExposureIndex).coerceIn(range.lower, range.upper))
    }

    /** 背面 ⇔ 前面カメラを切り替える。録画中は無効。 */
    fun toggleLens() {
        if (_isRecording.value) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        cachedPreviewView?.let { startCamera(it, cachedQrCallback) }
    }

    /** 動画エンコーダを画質プリセットと比率で組み立てる(ビットレートはCameraXが決める) */
    private fun buildRecorder(quality: VideoQuality, aspect: Int): Recorder {
        val builder = Recorder.Builder().setQualitySelector(
            QualitySelector.from(
                when (quality) {
                    VideoQuality.FHD -> Quality.FHD
                    VideoQuality.HD -> Quality.HD
                    VideoQuality.SD -> Quality.SD
                },
                FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
            )
        )
        // 比率指定は対応バージョンのみ有効。無い場合は既定値で動く
        try {
            Recorder.Builder::class.java
                .getMethod("setAspectRatio", Int::class.javaPrimitiveType)
                .invoke(builder, aspect)
        } catch (_: Throwable) {
        }
        return builder.build()
    }

    /** ズーム倍率(1〜10倍)。端末が対応する最大倍率より大きい値は、その最大倍率に抑える */
    fun setZoom(ratio: Float) {
        val cam = camera ?: return
        val deviceMax = cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 10f
        val clamped = ratio.coerceIn(1f, minOf(10f, deviceMax))
        cam.cameraControl.setZoomRatio(clamped)
        _zoomRatio.value = clamped
    }

    fun setFlashMode(mode: FlashMode) {
        flashMode = mode
        applyHardwareControls()
    }

    /** マクロ(近距離固定)のオン・オフ。PHOTO モードでのみ効く */
    @Volatile
    var macroOn: Boolean = false
        private set

    /** この端末のマクロ専用の物理カメラ(無ければ null) */
    private val macroPhysicalId: String? by lazy { CameraInfo.macroPhysicalId(context) }

    /** マクロ用の物理カメラを使うのは、PHOTO かつマクロオンのとき(背面のみ) */
    private fun macroCameraIdForPhoto(): String? =
        if (macroOn && currentMode == FilmMode.PHOTO && lensFacing != CameraSelector.LENS_FACING_FRONT) macroPhysicalId else null

    /** レンズダイアログの「OK」。保存するかどうかを決めて、Google レンズに送る */
    fun resolveLens(saveToGallery: Boolean) {
        val shot = LensShare.pending.value ?: return
        LensShare.pending.value = null
        scope.launch {
            if (saveToGallery) {
                val filename = "MF_${shot.mode}_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
                val publicUri = withContext(Dispatchers.IO) {
                    MediaStorageHelper.saveImageToPublicGallery(context, shot.bitmap, filename, shot.quality)
                }
                publicUri?.let { ExifHelper.writeTo(context, it, emptyMap()) }
                val savedUri = publicUri?.toString() ?: ""
                val entity = FilmPhoto(
                    filePath = savedUri,
                    uriString = savedUri,
                    timestamp = System.currentTimeMillis(),
                    formattedDate = shot.dateStr,
                    mode = shot.mode,
                    isLandscape = shot.isLandscape,
                    width = shot.targetW,
                    height = shot.targetH,
                    iso = currentMode.defaultIso,
                    hasDateStamp = shot.hasDateStamp,
                    quality = shot.quality,
                    macro = shot.macro
                )
                val id = withContext(Dispatchers.IO) {
                    database.filmPhotoDao().insertPhoto(entity)
                }
                _latestCapturedPhoto.value = entity.copy(id = id)
            }
            try {
                LensShare.send(context, shot.file)
            } catch (_: Exception) {
            }
        }
    }

    /** レンズダイアログの「キャンセル」。撮った写真は、端末にもアプリにも残さず捨てる */
    fun cancelLens() {
        val shot = LensShare.pending.value ?: return
        LensShare.pending.value = null
        shot.file.delete()
    }

    fun setMacro(on: Boolean) {
        val changed = macroOn != on
        macroOn = on
        if (changed && macroPhysicalId != null && currentMode == FilmMode.PHOTO) {
            // マクロ専用カメラに切り替えるため、組み直す
            cachedPreviewView?.let { startCamera(it, cachedQrCallback) }
        } else {
            applyHardwareControls()
        }
    }

    fun setExposureIndex(index: Int) {
        exposureIndex = index
        applyHardwareControls()
    }

    /** 今のレンズが前面カメラか(前面のフラッシュON時は疑似フラッシュにする) */
    val isFrontLens: Boolean
        get() = lensFacing == CameraSelector.LENS_FACING_FRONT

    /**
     * PHOTOモード: タップした位置にピント(AF)と露出(AE)を合わせる。
     * 明るい場所(白飛びしそう)は露出を下げ、暗い場所(黒つぶれしそう)は上げる。
     * AF_RESUME_MS 後に連続AFと通常の露出へ戻す。
     */
    // 長押しのピント固定(静止画のみ): 押している間、プレビューの中心にピントを合わせ続ける
    private var holdActive = false

    /** 長押しを始める。静止画(PHOTO・FUJI・KODA)のときだけ true */
    fun beginHoldFocus(): Boolean {
        if (currentMode != FilmMode.PHOTO && currentMode != FilmMode.FUJI && currentMode != FilmMode.KODA) return false
        if (camera == null || cachedPreviewView == null) return false
        holdActive = true
        refreshHoldFocus()
        return true
    }

    /** 押している間、中心に合わせ直す(自動解除しない) */
    fun refreshHoldFocus() {
        if (!holdActive) return
        val cam = camera ?: return
        val view = cachedPreviewView ?: return
        if (view.width <= 0 || view.height <= 0) return
        val point = view.meteringPointFactory.createPoint(view.width / 2f, view.height / 2f)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).disableAutoCancel().build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    /** 指を離した: ピント固定を解除する(連続AFへ戻す) */
    fun endHoldFocus() {
        if (!holdActive) return
        holdActive = false
        camera?.cameraControl?.cancelFocusAndMetering()
    }

    /** 反応したら true(画面側でバイブさせるために使う)。PHOTO以外・準備前は false */
    fun focusAt(x: Float, y: Float): Boolean {
        if (currentMode != FilmMode.PHOTO) return false
        val cam = camera ?: return false
        val view = cachedPreviewView ?: return false

        val point = view.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        )
            .setAutoCancelDuration(AF_RESUME_MS / 1000L, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)

        // 露出: タップ位置の明るさから、中間グレー(TAP_TARGET_LUMA)に近づける補正量を決める。
        // 明るい所は下げ、暗い所は上げる。段数は補正の1ステップ(端末ごと)に換算し、±TAP_MAX_EV の範囲に収める
        // タップ位置を、画面上の割合(0〜1)で解析画像に対応させる(センサー基準の座標は向きがずれることがあるため使わない)
        val luma = if (view.width > 0 && view.height > 0) {
            sampleLuma(x / view.width, y / view.height)
        } else {
            null
        }
        val stepEv = cam.cameraInfo.exposureState.exposureCompensationStep.toDouble()
        tapExposureIndex = if (luma == null || stepEv <= 0.0) {
            0
        } else {
            // 明るさ(ガンマ値)を光量の比に変換する(約2.2乗)
            val ev = (TAP_GAMMA * kotlin.math.log2(TAP_TARGET_LUMA / luma.coerceAtLeast(1).toDouble()))
                .coerceIn(-TAP_MAX_EV, TAP_MAX_EV)
            kotlin.math.round(ev / stepEv).toInt()
        }
        _tapDebug.value = "タップ: 明るさ ${luma ?: "-"} / 補正 $tapExposureIndex"
        applyHardwareControls()

        // 一定時間後に露出のタップ補正を外す(AFは CameraX の自動解除で連続AFに戻る)
        mainHandler.removeCallbacks(resumeAfterTapRunnable)
        mainHandler.postDelayed(resumeAfterTapRunnable, AF_RESUME_MS)
        return true
    }

    /** 直近の解析フレーム(Yプレーン=明るさ)の、指定位置の周辺平均を返す。無ければ null */
    private fun sampleLuma(nx: Float, ny: Float): Int? {
        val frame = lumaFrame ?: return null
        val w = lumaW
        val h = lumaH
        if (w <= 0 || h <= 0 || frame.size < w * h) return null
        val cx = (nx * w).toInt().coerceIn(0, w - 1)
        val cy = (ny * h).toInt().coerceIn(0, h - 1)
        var sum = 0
        var n = 0
        for (dy in -4..4) {
            for (dx in -4..4) {
                val px = (cx + dx).coerceIn(0, w - 1)
                val py = (cy + dy).coerceIn(0, h - 1)
                sum += frame[py * w + px].toInt() and 0xFF
                n++
            }
        }
        return sum / n
    }

    fun updateSettings(
        mode: FilmMode,
        settings: FilterSettings,
        dateStamp: Boolean,
        sound: Boolean
    ) {
        val modeChanged = this.currentMode != mode
        this.currentMode = mode
        this.filterSettings = settings
        this.hasDateStamp = dateStamp
        this.shutterSoundEnabled = sound

        if (modeChanged) {
            cachedPreviewView?.let { startCamera(it, cachedQrCallback) }
        } else {
            applyHardwareControls()
        }
    }

    /**
     * Starts video recording in MOV mode.
     */
    @SuppressLint("MissingPermission")
    fun startRecording(onVideoSaved: ((FilmPhoto) -> Unit)? = null) {
        val capture = videoCapture ?: return
        if (_isRecording.value) return

        // 動画は DCIM/MellowFilm へ直接書き込む(アプリ内にコピーは残さない)
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "MellowFilm_${currentMode.id}_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, FolderSync.RELATIVE_PATH)
        }
        val outputOptions = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        soundManager.playVideoStartSound(shutterSoundEnabled)

        // 録画開始の時点の端末の向きを、動画の回転情報(ファイルに書き込まれる向き)にする。
        // 起動時の向きのままだと、横持ちで撮っても再生が横向きにならないため
        // VHS(MOV_VHS)は向きを ROTATION_90 に固定しているので、ここでは変えない
        if (currentMode == FilmMode.MOV) {
            capture.targetRotation = surfaceRotationConst(orientationManager.surfaceRotationDegrees)
        }

        val pendingRecording = capture.output.prepareRecording(context, outputOptions)
        // Record microphone audio only when the permission is granted (otherwise start() would throw)
        val hasAudioPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        val recording = (if (hasAudioPermission) pendingRecording.withAudioEnabled() else pendingRecording)
            .start(ContextCompat.getMainExecutor(context)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        VhsOsdState.isRecording = true
                        _isRecording.value = true
                        _recordingSeconds.value = 0
                    }
                    is VideoRecordEvent.Status -> {
                        val nanos = event.recordingStats.recordedDurationNanos
                        _recordingSeconds.value = nanos / 1_000_000_000L
                    }
                    is VideoRecordEvent.Finalize -> {
                        VhsOsdState.isRecording = false
                        _isRecording.value = false
                        if (!event.hasError()) {
                            scope.launch {
                                val savedUri = event.outputResults.outputUri.toString()

                                val photo = FilmPhoto(
                                    filePath = savedUri,
                                    uriString = savedUri,
                                    timestamp = System.currentTimeMillis(),
                                    formattedDate = DateStampRenderer.extractDateString(null),
                                    mode = currentMode.id,
                                    // VHS clips are always landscape 4:3
                                    isLandscape = currentMode == FilmMode.MOV_VHS ||
                                        orientationManager.orientation.value.isLandscape,
                                    width = if (currentMode == FilmMode.MOV_VHS) 960 else 720,
                                    height = if (currentMode == FilmMode.MOV_VHS) 720 else 960,
                                    iso = 400,
                                    hasDateStamp = hasDateStamp,
                                    quality = 80
                                )
                                withContext(Dispatchers.IO) {
                                    database.filmPhotoDao().insertPhoto(photo)
                                }
                                _latestCapturedPhoto.value = photo
                                onVideoSaved?.invoke(photo)
                            }
                        }
                    }
                }
            }
        activeRecording = recording
    }

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    /** 録画の一時停止・再開(押すたびに切り替え) */
    fun togglePauseRecording() {
        val rec = activeRecording ?: return
        if (_isPaused.value) {
            rec.resume()
            _isPaused.value = false
        } else {
            rec.pause()
            _isPaused.value = true
        }
    }

    fun stopRecording() {
        soundManager.playVideoStopSound(shutterSoundEnabled)
        activeRecording?.stop()
        activeRecording = null
        _isPaused.value = false
        VhsOsdState.isRecording = false
        _isRecording.value = false
    }

    fun toggleRecording(onVideoSaved: ((FilmPhoto) -> Unit)? = null) {
        if (_isRecording.value) {
            stopRecording()
        } else {
            startRecording(onVideoSaved)
        }
    }

    /**
     * Executes minimal-latency shutter capture.
     * Fires shutter sound immediately, processes bitmap asynchronously,
     * burns date stamp based on orientation, and saves as 80-90% JPG.
     */
    fun takePhoto(onPhotoCaptured: ((FilmPhoto) -> Unit)? = null) {
        val capture = imageCapture ?: return
        beginCapture()

        // 1. Play Shutter Sound immediately (forced or silent based on toggle)
        soundManager.playShutterSound(shutterSoundEnabled)

        val orientation = orientationManager.orientation.value
        val isLandscape = orientation.isLandscape

        // 撮影時の向きは画面の自動回転設定に関係なく、端末のセンサー傾きで決める
        capture.targetRotation = surfaceRotationConst(orientationManager.surfaceRotationDegrees)

        capture.takePicture(
            cameraExecutor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    processCapturedImage(image, isLandscape, onPhotoCaptured)
                }

                override fun onError(exception: ImageCaptureException) {
                    endCapture()
                }
            }
        )
    }

    private fun processCapturedImage(
        image: ImageProxy,
        isLandscape: Boolean,
        onPhotoCaptured: ((FilmPhoto) -> Unit)?
    ) {
        try {
            val tStart = System.nanoTime()
            val buffer: ByteBuffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)

            // Adjust bitmap rotation to sensor orientation
            val rotationDegrees = image.imageInfo.rotationDegrees
            image.close()

            // Target size: PHOTO follows the saved preset; film modes are fixed at 1500 x 2000 (3:4)
            val preset = if (currentMode == FilmMode.PHOTO) prefs.photoQuality.value else null
            val baseW = preset?.width ?: 1500
            val baseH = preset?.height ?: 2000
            val targetW = if (isLandscape) baseH else baseW
            val targetH = if (isLandscape) baseW else baseH

            // 目標サイズより大きすぎる場合は、読み込み時に 1/2, 1/4... へ縮小して処理量を減らす(速度・メモリ対策)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val swapped = rotationDegrees == 90 || rotationDegrees == 270
            val rw = if (swapped) bounds.outHeight else bounds.outWidth
            val rh = if (swapped) bounds.outWidth else bounds.outHeight
            val minTarget = minOf(targetW, targetH)
            val maxTarget = maxOf(targetW, targetH)
            var sample = 1
            while (minOf(rw, rh) / (sample * 2) >= minTarget && maxOf(rw, rh) / (sample * 2) >= maxTarget) {
                sample *= 2
            }
            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)

            if (rotationDegrees != 0) {
                val matrix = Matrix()
                matrix.postRotate(rotationDegrees.toFloat())
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            }

            val scaledBitmap = if (bitmap.width == targetW && bitmap.height == targetH) {
                bitmap
            } else {
                Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
            }

            val tDecoded = System.nanoTime()

            // 1. Film pipeline (FUJI/KODA: 10 steps incl. date stamp; PHOTO passes through unchanged)
            val dateStr = DateStampRenderer.extractDateString(null)
            val isFilm = currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA
            // 加工に失敗しても撮影結果は必ず保存する(失敗時は加工前の画像を使う)
            val finalBitmap = try {
                ImageProcessor.renderCapture(
                source = scaledBitmap,
                mode = currentMode,
                lut = LutRepository.current(currentMode),
                flashOff = flashMode == FlashMode.OFF,
                grainStrength = prefs.grain.value / 100f,
                vignetteStrength = prefs.vignette.value / 100f,
                hasDateStamp = hasDateStamp && isFilm,
                isLandscape = isLandscape,
                dateString = dateStr,
                dateStyle = prefs.dateStampStyle.value,
                gpu = prefs.gpuFilm.value
                )
            } catch (t: Throwable) {
                android.util.Log.e("CameraEngine", "加工に失敗したため、加工前の画像で保存します", t)
                scaledBitmap
            }

            val tProcessed = System.nanoTime()

            // 前面カメラのPHOTOで「左右反転」がオンなら、保存する写真だけ反転する(プレビューは反転しない)
            val mirror = currentMode == FilmMode.PHOTO &&
                lensFacing == CameraSelector.LENS_FACING_FRONT &&
                prefs.mirrorFront.value
            // 色温度(PHOTO のみ)。プレビューと同じ係数を写真にも掛ける
            val tintedBase = if (currentMode == FilmMode.PHOTO) {
                ColorTemp.apply(finalBitmap, prefs.colorTemp.value)
            } else {
                finalBitmap
            }
            // EV ±4・±5 の分のデジタルの明るさ(PHOTO のみ)
            val tinted = if (currentMode == FilmMode.PHOTO) {
                DigitalExposure.apply(tintedBase, DigitalExposure.gainFor(exposureIndex))
            } else {
                tintedBase
            }
            val outBitmap = if (mirror) {
                Bitmap.createBitmap(
                    tinted, 0, 0, tinted.width, tinted.height,
                    Matrix().apply {
                        // 中心を軸にして左右に反転する(原点を軸にすると画像が画面の外へ出てしまう)
                        postScale(-1f, 1f, tinted.width / 2f, tinted.height / 2f)
                    }, true
                )
            } else {
                tinted
            }

            val quality = preset?.jpegQuality ?: 80

            // Google レンズモード(PHOTO): 保存せず一時ファイルに置き、ダイアログで決めてもらう
            if (LensShare.hold.value && currentMode == FilmMode.PHOTO) {
                // 1枚撮ったら、レンズのボタンはオフに戻す
                LensShare.hold.value = false
                val lensDir = File(context.cacheDir, "lens").apply { mkdirs() }
                val lensFile = File(lensDir, "lens_${System.currentTimeMillis()}.jpg")
                FileOutputStream(lensFile).use { out ->
                    outBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, out)
                }
                LensShare.pending.value = PendingLensShot(
                    bitmap = outBitmap,
                    file = lensFile,
                    dateStr = dateStr,
                    mode = currentMode.id,
                    isLandscape = isLandscape,
                    targetW = targetW,
                    targetH = targetH,
                    quality = quality,
                    hasDateStamp = hasDateStamp,
                    macro = macroOn
                )
                endCapture()
                return
            }

            // 3. Save to DCIM/MellowFilm (the only storage location)
            val filename = "MF_${currentMode.id}_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
            val publicUri = MediaStorageHelper.saveImageToPublicGallery(context, outBitmap, filename, quality)
            publicUri?.let { ExifHelper.writeTo(context, it, emptyMap()) }
            val savedUri = publicUri?.toString() ?: ""
            val tSaved = System.nanoTime()
            val timing = "現像: 読込 ${(tDecoded - tStart) / 1_000_000} / 加工 ${(tProcessed - tDecoded) / 1_000_000} / 保存 ${(tSaved - tProcessed) / 1_000_000} ms"

            // 4. Save to Database
            val entity = FilmPhoto(
                filePath = savedUri,
                uriString = savedUri,
                timestamp = System.currentTimeMillis(),
                formattedDate = dateStr,
                mode = currentMode.id,
                isLandscape = isLandscape,
                width = targetW,
                height = targetH,
                iso = currentMode.defaultIso,
                hasDateStamp = hasDateStamp,
                quality = quality,
                macro = macroOn && currentMode == FilmMode.PHOTO
            )

            scope.launch {
                val id = withContext(Dispatchers.IO) {
                    database.filmPhotoDao().insertPhoto(entity)
                }
                val savedEntity = entity.copy(id = id)
                _latestCapturedPhoto.value = savedEntity
                endCapture()
                // 現像時間を数秒だけ表示する(どこで時間がかかっているかの確認用)
                _timingDebug.value = timing
                mainHandler.removeCallbacks(clearTimingRunnable)
                mainHandler.postDelayed(clearTimingRunnable, 4000L)
                onPhotoCaptured?.invoke(savedEntity)
            }
        } catch (_: Exception) {
            endCapture()
        }
    }

    // ------------------------------------------------------------------
    // VHS pipeline
    // ------------------------------------------------------------------

    /**
     * Binds Preview + VideoCapture with one shared GL effect (VhsEffect).
     * - Both use cases are fixed to ROTATION_90 so buffers are always landscape 4:3;
     *   the shader rotates/crops the image according to the real device orientation.
     * - Preview is rendered into a TextureView supplied by the UI (see attachVhsTextureView).
     */
    @SuppressLint("UnsafeOptInUsageError")
    private fun bindVhsPipeline() {
        val provider = cameraProvider ?: return
        _vhsError.value = null
        _filmGpuActive.value = false

        val processor = vhsProcessor ?: VhsGlProcessor { t ->
            _vhsError.value = "VHSエフェクトのエラー: ${t.javaClass.simpleName}: ${t.message}"
        }.also {
            // 出力バッファは targetRotation(ROTATION_90)固定の横長なので、向きの基準もそれに合わせる
            it.deviceRotationProvider = { 90 } // degrees (CameraX convention), not Surface.ROTATION_* constants
            vhsProcessor = it
        }

        val vhsPreview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            // 映像は回さない(レンズから見えるまま)。向きで回すのは枠と文字だけ
            .setTargetRotation(Surface.ROTATION_90)
            .build()
        vhsPreview.setSurfaceProvider(ContextCompat.getMainExecutor(context)) { request ->
            serveVhsPreviewRequest(request)
        }

        // VHS clips are always 4:3; resolution follows the user's video quality preset
        val recorder = buildRecorder(prefs.videoQuality.value, AspectRatio.RATIO_4_3)
        val vhsVideo = VideoCapture.withOutput(recorder)
        vhsVideo.targetRotation = Surface.ROTATION_90

        preview = vhsPreview
        videoCapture = vhsVideo
        imageAnalysis = null

        try {
            val group = UseCaseGroup.Builder()
                .addUseCase(vhsPreview)
                .addUseCase(vhsVideo)
                .addEffect(VhsEffect(processor))
                .build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(
                lifecycleOwner,
                if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                },
                group
            )
            camera?.cameraInfo?.sensorRotationDegrees?.let { processor.sensorRotationDegrees = it }
            processor.frontCamera = lensFacing == CameraSelector.LENS_FACING_FRONT
            applyHardwareControls()
        } catch (e: Exception) {
            _vhsError.value = "VHSの起動に失敗: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun isGpuFilmMode(): Boolean =
        GPU_LIVE_PREVIEW && (currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA) && prefs.gpuFilm.value

    /** FUJI/KODA の GPU プレビュー。Preview(3:4・縦)+ 撮影 + 加工エフェクトを一緒に束ねる */
    @SuppressLint("UnsafeOptInUsageError")
    private fun bindFilmPipeline() {
        val provider = cameraProvider ?: return
        val processor = filmProcessor ?: FilmGlProcessor(
            settingsProvider = { filmGlSettings() },
            onError = { t -> onFilmGpuError(t) },
            onDebug = { _filmDebug.value = it },
            onOutputBroken = {
                if (brokenRebinds < 5) {
                    brokenRebinds++
                    mainHandler.post { reapplyCamera() }
                }
            }
        ).also { filmProcessor = it }

        val filmPreview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setTargetRotation(Surface.ROTATION_0)
            .build()
        filmPreview.setSurfaceProvider(ContextCompat.getMainExecutor(context)) { request ->
            serveVhsPreviewRequest(request)
        }
        val capture = ImageCapture.Builder()
            .setCaptureMode(androidx.camera.core.ImageCapture.CAPTURE_MODE_ZERO_SHUTTER_LAG)
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .build()

        preview = filmPreview
        imageCapture = capture
        videoCapture = null
        imageAnalysis = null

        try {
            val group = UseCaseGroup.Builder()
                .addUseCase(filmPreview)
                .addUseCase(capture)
                .addEffect(FilmEffect(processor))
                .build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(
                lifecycleOwner,
                if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                },
                group
            )
            _filmGpuActive.value = true
            _gpuPreviewError.value = null
            applyHardwareControls()
        } catch (e: Exception) {
            onFilmGpuError(e)
        }
    }

    /** 加工の設定を、描画のたびに設定値から作る(撮影時と同じ入力) */
    private fun filmGlSettings(): FilmGlSettings {
        val isFilm = currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA
        return FilmGlSettings(
            mode = currentMode,
            flashOff = flashMode == FlashMode.OFF,
            grainStrength = prefs.grain.value / 100f,
            vignetteStrength = prefs.vignette.value / 100f,
            lut = LutRepository.current(currentMode),
            style = prefs.dateStampStyle.value,
            hasDateStamp = hasDateStamp && isFilm,
            // プレビューの日付は向きに関係なく左下・縦書きに固定(案A・試験。位置は設定の変更時だけ動く)
            isLandscape = false
        )
    }

    /** GPU プレビューが失敗したら、通常(CPU)の表示に戻す。GL スレッドから呼ばれる */
    private fun onFilmGpuError(t: Throwable) {
        mainHandler.post {
            if (filmGpuFallback) return@post
            filmGpuFallback = true
            _filmGpuActive.value = false
            _gpuPreviewError.value = "GPUプレビューを止め、通常表示に戻しました: ${t.javaClass.simpleName}: ${t.message}"
            cachedPreviewView?.let { startCamera(it, cachedQrCallback) }
        }
    }

    /** 設定(GPU プレビューの on/off など)を変えたとき、カメラを組み直す */
    fun reapplyCamera() {
        filmGpuFallback = false
        brokenRebinds = 0
        cachedPreviewView?.let { startCamera(it, cachedQrCallback) }
    }

    private fun serveVhsPreviewRequest(request: SurfaceRequest) {
        val tv = vhsTextureView
        val st = tv?.surfaceTexture
        if (tv != null && st != null && tv.isAvailable) {
            val res = request.resolution
            st.setDefaultBufferSize(res.width, res.height)
            val surface = Surface(st)
            request.provideSurface(surface, ContextCompat.getMainExecutor(context)) {
                surface.release()
            }
        } else {
            // The TextureView is not ready yet; serve the request as soon as it is attached.
            pendingVhsRequest?.willNotProvideSurface()
            pendingVhsRequest = request
        }
    }

    /** Called by the UI when the VHS TextureView becomes available (or null when it is destroyed). */
    fun attachVhsTextureView(tv: TextureView?) {
        vhsTextureView = tv
        if (tv != null && tv.isAvailable) {
            val pending = pendingVhsRequest
            if (pending != null) {
                pendingVhsRequest = null
                serveVhsPreviewRequest(pending)
            } else if (_filmGpuActive.value) {
                // 画面が作り直された(ギャラリーから戻った等)。古い描画先のままなので、接続を組み直す
                mainHandler.post { reapplyCamera() }
            }
        }
    }

    fun release() {
        cameraExecutor.shutdown()
        cameraProvider?.unbindAll()
        vhsProcessor?.release()
        vhsProcessor = null
        filmProcessor?.release()
        filmProcessor = null
    }
}
