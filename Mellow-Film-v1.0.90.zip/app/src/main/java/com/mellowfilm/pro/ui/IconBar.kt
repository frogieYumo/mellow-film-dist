package com.mellowfilm.pro.ui
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Visibility

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BlurCircular
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.rotate
import com.mellowfilm.pro.camera.DeviceOrientation
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.ui.unit.sp
import com.mellowfilm.pro.data.prefs.PhotoQuality
import com.mellowfilm.pro.data.prefs.VideoAspect
import com.mellowfilm.pro.data.prefs.VideoQuality
import com.mellowfilm.pro.filter.FilmMode
import kotlin.math.roundToInt

/** アイコンバーから開くスライド式の強度バーの種類 */
private enum class BarKind { EV, VIGNETTE, GRAIN }

/**
 * プレビュー下のアイコンバー。モードごとに中身が変わる。
 *  - FUJI / KODA : ビネット・グレイン・一括取り込み・日付
 *  - PHOTO       : 左端に EV(露出バー) / 右端に画質(高・中・低)
 *  - MOV / VHS   : 右端に画質(FHD・HD・SD)
 *  - QR          : なし
 * 「?」を押すと画質の解説を表示する。
 */
@Composable
fun IconBar(
    viewModel: MellowFilmViewModel,
    currentMode: FilmMode,
    dateStampEnabled: Boolean,
    accentColor: Color,
    onImportBatch: () -> Unit,
    onToggleDateStamp: () -> Unit
) {
    val prefs = viewModel.prefs
    val exposureEV by viewModel.exposureEV.collectAsState()
    val vignette by prefs.vignette.collectAsState()
    val grain by prefs.grain.collectAsState()
    val videoQuality by prefs.videoQuality.collectAsState()
    val photoQuality by prefs.photoQuality.collectAsState()
    val videoAspect by prefs.videoAspect.collectAsState()

    var openBar by remember { mutableStateOf<BarKind?>(null) }
    val vhsOsd by viewModel.vhsOsd.collectAsState()
    // 端末の向きに合わせてアイコンだけを回す(文字・モードタブ・シャッターは回さない)
    val iconAngle = rememberIconAngle(viewModel.deviceOrientation.collectAsState().value)
    var helpOpen by remember { mutableStateOf(false) }

    // モードを変えたら開いているバーは閉じる
    LaunchedEffect(currentMode) { openBar = null }

    val isFilm = currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA
    val isPhoto = currentMode == FilmMode.PHOTO
    val isMovie = currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
        contentAlignment = Alignment.Center
    ) {
        // 強度バー(アイコンバーの左からスライドして出る)
        AnimatedVisibility(
            visible = openBar != null,
            enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut()
        ) {
            val bar = openBar
            if (bar != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val spec = when (bar) {
                        BarKind.EV -> Quad(
                            "EV: ${if (exposureEV > 0) "+$exposureEV" else exposureEV}",
                            exposureEV.toFloat(),
                            -5f..5f
                        ) { viewModel.setExposureEV(it.roundToInt()) }
                        BarKind.VIGNETTE -> Quad(
                            "減光 ${vignette}%",
                            vignette.toFloat(),
                            0f..100f
                        ) { prefs.setVignette(it.roundToInt()) }
                        BarKind.GRAIN -> Quad(
                            "粒子 ${grain}%",
                            grain.toFloat(),
                            0f..100f
                        ) { prefs.setGrain(it.roundToInt()) }
                    }

                    Text(
                        text = spec.label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(72.dp)
                    )
                    Slider(
                        value = spec.value,
                        onValueChange = spec.onChange,
                        valueRange = spec.range,
                        steps = if (bar == BarKind.EV) 9 else 0,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor
                        )
                    )
                    IconButton(modifier = Modifier.rotate(iconAngle), onClick = { openBar = null }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "閉じる",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // 通常のアイコン表示(強度バーを開いている間は隠す)
        AnimatedVisibility(
            visible = openBar == null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 左側(PHOTO: EV | タイマー マクロ / FUJI・KODA: ビネット グレイン | タイマー)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isPhoto) {
                        TextButton(onClick = { openBar = BarKind.EV }) {
                            Text("EV:${if (exposureEV > 0) "+$exposureEV" else "$exposureEV"}", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Separator()
                        if (viewModel.macroAvailable) {
                            val macroOn by viewModel.macroOn.collectAsState()
                            IconButton(modifier = Modifier.rotate(iconAngle), onClick = { viewModel.toggleMacro() }) {
                                // オンは白の花、オフは灰色の斜線付き(macro_off)
                                MaterialSymbol(
                                    if (macroOn) "local_florist" else "macro_off",
                                    tint = if (macroOn) Color.White else Color.White.copy(alpha = 0.35f),
                                    size = 24.dp
                                )
                            }
                        }
                        // PHOTO: EV | マクロ タイマー(マクロは対応端末のみ)
                        TimerChip(viewModel = viewModel, iconAngle = iconAngle, onFilm = false)
                    }
                    if (isFilm) {
                        IconButton(modifier = Modifier.rotate(iconAngle), onClick = { openBar = BarKind.VIGNETTE }) {
                            Icon(Icons.Default.BlurCircular, contentDescription = "ビネット", tint = Color.White)
                        }
                        IconButton(modifier = Modifier.rotate(iconAngle), onClick = { openBar = BarKind.GRAIN }) {
                            Icon(Icons.Default.Grain, contentDescription = "グレイン", tint = Color.White)
                        }
                        Separator(color = Color.White)
                        TimerChip(viewModel = viewModel, iconAngle = iconAngle, onFilm = true)
                    }
                }

                // 右側: 画質ボタン + 解説(?)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isPhoto) {
                        Separator()
                        TextButton(onClick = {
                            val next = when (photoQuality) {
                                PhotoQuality.HIGH -> PhotoQuality.MEDIUM
                                PhotoQuality.MEDIUM -> PhotoQuality.LOW
                                PhotoQuality.LOW -> PhotoQuality.HIGH
                            }
                            prefs.setPhotoQuality(next)
                        }) {
                            Text(
                                "画質:" + when (photoQuality) {
                                    PhotoQuality.HIGH -> "高"
                                    PhotoQuality.MEDIUM -> "中"
                                    PhotoQuality.LOW -> "低"
                                },
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (currentMode == FilmMode.MOV) {
                        // 標準動画の比率(16:9 / 4:3)。VHSは常に4:3なのでボタンを出さない
                        TextButton(onClick = {
                            prefs.setVideoAspect(
                                if (videoAspect == VideoAspect.WIDE_16_9) VideoAspect.STANDARD_4_3
                                else VideoAspect.WIDE_16_9
                            )
                            // 比率は録画・プレビューの設定時に決まるため、カメラを組み直して反映する
                            viewModel.cameraEngine?.reapplyCamera()
                        }) {
                            Text(
                                if (videoAspect == VideoAspect.WIDE_16_9) "16:9" else "4:3",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (currentMode == FilmMode.MOV) {
                        TextButton(onClick = {
                            val next = when (videoQuality) {
                                VideoQuality.FHD -> VideoQuality.HD
                                VideoQuality.HD -> VideoQuality.SD
                                VideoQuality.SD -> VideoQuality.FHD
                            }
                            prefs.setVideoQuality(next)
                        }) {
                            Text(
                                videoQuality.name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (isPhoto || currentMode == FilmMode.MOV) {
                        // ボタンの位置は回転させず、アイコンだけ回す(回すと位置のずれが縦方向に出るため)
                        IconButton(
                            modifier = Modifier.size(22.dp).offset(x = (-12).dp),
                            onClick = { helpOpen = true }
                        ) {
                            Icon(
                                Icons.Default.HelpOutline,
                                contentDescription = "画質の解説",
                                tint = Color.White,
                                modifier = Modifier.rotate(iconAngle).size(13.dp)
                            )
                        }
                    }
                    if (isFilm) {
                        // フィルムモードの一括取り込み・日付は右端
                        IconButton(modifier = Modifier.rotate(iconAngle), onClick = onImportBatch) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = "一括取り込み", tint = Color.White)
                        }
                        IconButton(modifier = Modifier.rotate(iconAngle), onClick = onToggleDateStamp) {
                            Icon(
                                Icons.Default.CalendarToday,
                                contentDescription = "日付スタンプ",
                                tint = Color.White.copy(alpha = if (dateStampEnabled) 1f else 0.35f)
                            )
                        }
                    }
                }
            }
        }
    }

    if (helpOpen) {
        QualityHelpDialog(isPhoto = isPhoto, onDismiss = { helpOpen = false })
    }
}

/** 強度バーの表示内容(ラベル・現在値・範囲・変更時の処理) */
private data class Quad(
    val label: String,
    val value: Float,
    val range: ClosedFloatingPointRange<Float>,
    val onChange: (Float) -> Unit
)

@Composable
private fun QualityHelpDialog(isPhoto: Boolean, onDismiss: () -> Unit) {
    val body = if (isPhoto) {
        "高: 3000×4000 / 圧縮率 90%\n細部まで残るが、ファイルは大きくなります。\n\n" +
            "中: 1500×2000 / 圧縮率 90%\n標準の大きさです。フィルムモードと同じ解像度です。\n\n" +
            "低: 1000×1333 / 圧縮率 80%\n小さく軽いファイルになります。"
    } else {
        "FHD: 1920×1080 相当\n最も鮮明ですが、ファイルは大きくなります。\n\n" +
            "HD: 1280×720 相当\n画質と容量のバランスが良い設定です。\n\n" +
            "SD: 720×480 相当\n小さく軽いファイルになります。\n\n" +
            "比率 16:9: 横長で録画します。プレビューは画面の中に収まり、空いた部分は黒帯になります。\n" +
            "比率 4:3: 従来の比率で録画します。\n\n" +
            "※ 実際の解像度は比率と端末により変わります。\n" +
            "※ 動画の圧縮率(ビットレート)はカメラの機能が自動で決めるため、アプリからは指定できません。"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("画質の目安", fontWeight = FontWeight.Bold) },
        text = { Text(body, fontSize = 13.sp) },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("閉じる") }
        }
    )
}

/** 端末の向きをアイコンの回転角(度)にする。横向きは逆に回して、アイコンが見た目で正立するようにする。 */
internal fun DeviceOrientation.iconAngle(): Float = when (this) {
    DeviceOrientation.PORTRAIT -> 0f
    DeviceOrientation.LANDSCAPE_LEFT -> -90f
    DeviceOrientation.PORTRAIT_REVERSE -> 180f
    DeviceOrientation.LANDSCAPE_RIGHT -> 90f // 符号を反転(横持ちの回転方向の修正)
}

/** 向きの変化を滑らかにつないだアイコン回転角 */
@Composable
internal fun rememberIconAngle(orientation: DeviceOrientation): Float {
    val angle by animateFloatAsState(
        targetValue = orientation.iconAngle(),
        animationSpec = tween(durationMillis = 300),
        label = "iconRotation"
    )
    return angle
}

/** 区切りの「|」(フィルムモードは白) */
@Composable
private fun Separator(color: Color = Color(0xFF888888)) {
    Text(
        text = "|",
        color = color,
        fontSize = 14.sp,
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}

/** タイマーの丸(時計アイコンの中に秒数を出す)。押すたびに OFF → 3 → 5 → 10 → OFF */
@Composable
private fun TimerChip(viewModel: MellowFilmViewModel, iconAngle: Float, onFilm: Boolean) {
    val timerOn by viewModel.timerEnabled.collectAsState()
    val timerSeconds by viewModel.timerSeconds.collectAsState()
    // タイマー ON のときの色。フィルムモード(FUJI/KODA)はボディの黄色に溶けるので白にする
    val accent = if (onFilm) Color.White else Color(0xFFF5B82E)
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .clickable { viewModel.cycleTimer() },
        contentAlignment = Alignment.Center
    ) {
        // OFF → 3秒 → 5秒 → 10秒 → OFF。OFF は灰色の Timer
        val iconModifier = Modifier.rotate(iconAngle)
        when {
            !timerOn -> MaterialSymbol("timer", tint = Color(0xFFAAAAAA), size = 26.dp, modifier = iconModifier)
            timerSeconds == 10 -> MaterialSymbol("timer_10_alt_1", tint = accent, size = 26.dp, modifier = iconModifier)
            timerSeconds == 5 -> MaterialSymbol("timer_5", tint = accent, size = 26.dp, modifier = iconModifier)
            else -> MaterialSymbol("timer_3_alt_1", tint = accent, size = 26.dp, modifier = iconModifier)
        }
    }
}
