package com.mellowfilm.pro.ui
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.net.Uri
import android.view.TextureView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.ui.geometry.Offset
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.mellowfilm.pro.camera.CameraEngine
import com.mellowfilm.pro.camera.FlashMode
import com.mellowfilm.pro.filter.FilmMode
import com.mellowfilm.pro.filter.FilterSettings
import com.mellowfilm.pro.data.prefs.AppPrefs
import com.mellowfilm.pro.data.prefs.PhotoQuality
import com.mellowfilm.pro.data.prefs.VideoAspect
import com.mellowfilm.pro.data.prefs.VideoQuality
import com.mellowfilm.pro.filter.DateStampRenderer
import com.mellowfilm.pro.filter.DateStampStyle
import com.mellowfilm.pro.gallery.GalleryScreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MellowFilmApp(viewModel: MellowFilmViewModel) {
    val screenState by viewModel.screenState.collectAsState()

    when (screenState) {
        ScreenState.CAMERA -> CameraScreen(viewModel)
        ScreenState.GALLERY -> GalleryScreen(
            dao = viewModel.database.filmPhotoDao(),
            onBackToCamera = { viewModel.setScreenState(ScreenState.CAMERA) }
        )
    }
}

@Composable
fun CameraScreen(viewModel: MellowFilmViewModel) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    // タップ位置の赤い印(位置と、連続タップで変わる番号)。3秒で消える
    var tapMarker by remember { mutableStateOf<Pair<Offset, Int>?>(null) }
    LaunchedEffect(tapMarker) {
        if (tapMarker != null) {
            delay(3000L)
            tapMarker = null
        }
    }

    val currentMode by viewModel.currentMode.collectAsState()
    val flashMode by viewModel.flashMode.collectAsState()
    val dateStampEnabled by viewModel.dateStampEnabled.collectAsState()
    val filterSettings by viewModel.filterSettings.collectAsState()
    val exposureEV by viewModel.exposureEV.collectAsState()
    val shutterFlash by viewModel.shutterFlash.collectAsState()
    val timerEnabled by viewModel.timerEnabled.collectAsState()
    val lensOnState by viewModel.lensOn.collectAsState()
    val flashMenuOpenState by viewModel.flashMenuOpen.collectAsState()
    val lensPending by com.mellowfilm.pro.camera.LensShare.pending.collectAsState()
    val timerSeconds by viewModel.timerSeconds.collectAsState()
    val countdown by viewModel.countdown.collectAsState()
    val scannedQr by viewModel.scannedQrCode.collectAsState()
    val orientation by viewModel.deviceOrientation.collectAsState()
    val batchProgress by viewModel.batchProgress.collectAsState()
    val showBatchDialog by viewModel.showBatchDialog.collectAsState()
    val firstBatchPreview by viewModel.firstBatchPreview.collectAsState()
    val batchUris by viewModel.batchUris.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingSeconds by viewModel.recordingSeconds.collectAsState()
    val videoAspect by viewModel.prefs.videoAspect.collectAsState()
    // 標準動画を16:9で録る時だけ、4:3枠の中に黒帯を入れる
    val isWide = currentMode == FilmMode.MOV && videoAspect == VideoAspect.WIDE_16_9

    var showSettingsDialog by remember { mutableStateOf(false) }

    // Multi-Image Picker Launcher for Batch Processing
    val multiImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.onBatchImagesSelected(uris)
        }
    }

    // QR Image Picker Launcher
    val qrImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val contentResolver = context.contentResolver
            val bitmap = contentResolver.openInputStream(it)?.use { stream ->
                android.graphics.BitmapFactory.decodeStream(stream)
            }
            if (bitmap != null) {
                val result = com.mellowfilm.pro.qr.QrCodeAnalyzer.scanBitmap(bitmap)
                if (result != null) {
                    viewModel.onQrScanned(result)
                }
            }
        }
    }

    // Eagerly initialize CameraEngine so CameraX binds immediately on initial composition
    val cameraEngine = remember(context, lifecycleOwner) {
        viewModel.cameraEngine ?: CameraEngine(
            context = context,
            lifecycleOwner = lifecycleOwner,
            database = viewModel.database,
            soundManager = viewModel.soundManager,
            orientationManager = viewModel.orientationManager,
            prefs = viewModel.prefs
        ).also { viewModel.cameraEngine = it }
    }

    val vhsError by cameraEngine.vhsError.collectAsState()
    val gpuPreview by cameraEngine.filmGpuActive.collectAsState()
    val gpuError by cameraEngine.gpuPreviewError.collectAsState()
    val tapDebug by cameraEngine.tapDebug.collectAsState()
    val timingDebug by cameraEngine.timingDebug.collectAsState()
    // 現像中の枚数(0より大きい間、シャッターのリングをくるくる回す)
    val pendingCount by cameraEngine.pendingCount.collectAsState()
    // エンジン作成後に直接つなぐ(最初の描画で空の値に固定されて、起動時に小窓が空になっていた)
    val latestPhoto by cameraEngine.latestCapturedPhoto.collectAsState()
    val isPaused by cameraEngine.isPaused.collectAsState()
    val isVhs = currentMode == FilmMode.MOV_VHS

    val iconAngle = rememberIconAngle(orientation)
    val scope = rememberCoroutineScope()

    // 起動時と、アプリが前面に戻るたびに、左下の小窓の最新ファイルを読み直す
    DisposableEffect(lifecycleOwner) {
        cameraEngine.refreshLatestPhoto()
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) cameraEngine.refreshLatestPhoto()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val activity = context.findActivity()

    // シャッター: 前面カメラでフラッシュONの静止画は、画面の明るさを最大にして白く光らせてから撮り、後で元に戻す
    val onShutter: () -> Unit = {
        val isStill = currentMode != FilmMode.MOV && currentMode != FilmMode.MOV_VHS
        if (isStill && flashMode == FlashMode.ON && cameraEngine.isFrontLens) {
            // タイマーのカウント中にもう一度押したら取り消す(onShutterPressed が判断する)
            viewModel.onShutterPressed {
                scope.launch {
                    val window = activity?.window
                    val savedBrightness = window?.attributes?.screenBrightness ?: -1f
                    setScreenBrightness(window, 1f)
                    viewModel.setShutterFlash(true)
                    delay(350) // 明るさが反映されてから撮る
                    cameraEngine.takePhoto()
                    delay(350)
                    viewModel.setShutterFlash(false)
                    setScreenBrightness(window, savedBrightness) // -1 はシステム設定に戻す
                }
            }
        } else {
            viewModel.triggerShutter()
        }
    }

    // Body styling based on current mode
    val bodyColor = when (currentMode) {
        FilmMode.FUJI -> Color(0xFF14241D) // Classic QuickSnap Dark Forest Green
        FilmMode.KODA -> Color(0xFF2A2111) // FunSaver Warm Vintage Amber Brown
        FilmMode.PHOTO -> Color(0xFF121417) // Titanium Pro Camera Matte Black
        FilmMode.MOV -> Color(0xFF1C1318) // Vintage VHS Camcorder
        FilmMode.MOV_VHS -> Color(0xFF1C1318) // VHS effect mode
        FilmMode.QR -> Color(0xFF131722) // Cyber Scan Navy
        else -> Color(0xFF14241D)
    }

    val accentColor = when (currentMode) {
        FilmMode.FUJI -> Color(0xFF38A169)
        FilmMode.KODA -> Color(0xFF8E1712) // 黄色の上で見やすい濃い赤
        FilmMode.PHOTO -> Color(0xFF9C92FF)
        FilmMode.MOV -> Color(0xFFEC4899)
        FilmMode.MOV_VHS -> Color(0xFFEC4899)
        FilmMode.QR -> Color(0xFF08ADAE)
        else -> Color(0xFF38A169)
    }

    val skin = skinFor(currentMode)
    val soundEnabled by viewModel.soundEnabled.collectAsState()
    val vignetteValue by viewModel.prefs.vignette.collectAsState()
    val dateStampStyle by viewModel.prefs.dateStampStyle.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(skin.body)
            .then(
                // フラッシュメニューが開いているとき、その外を押したら閉じる
                if (flashMenuOpenState) Modifier.pointerInput(Unit) {
                    detectTapGestures { viewModel.setFlashMenu(false) }
                } else Modifier
            )
    ) {
        // KODA: ボディ上部を赤くする(右が高く、左へ緩やかな曲線で下がる)。プレビューの後ろに描く
        if (currentMode == FilmMode.KODA) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, 0.3125f * h)
                    cubicTo(0.75f * w, 0.40f * h, 0.35f * w, 0.49f * h, 0f, 0.526f * h)
                    close()
                }
                drawPath(path, color = skin.topBar)
            }
        }
        // FUJI: ボディ上部を緑にする(斜めの直線。左が低く、右が高い)。プレビューの後ろに描く
        if (currentMode == FilmMode.FUJI) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, 0.40f * h)
                    lineTo(0f, 0.71f * h)
                    close()
                }
                drawPath(path, color = skin.topBar)
            }
        }
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Retro Toolbar
            TopToolbar(
                currentMode = currentMode,
                flashMode = flashMode,
                dateStampEnabled = dateStampEnabled,
                soundEnabled = soundEnabled,
                onToggleSound = { viewModel.toggleSound() },
                accentColor = accentColor,
                skin = skin,
                onToggleLens = { viewModel.toggleLens() },
                onOpenSettings = { showSettingsDialog = true },
                iconAngle = iconAngle
            )

            // 2. Viewfinder Frame: fixed 3:4 normally, landscape 4:3 centered with black bars in VHS mode
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(if (isVhs) Color.Black else Color.Transparent)
                    .padding(
                        horizontal = if (isVhs) 0.dp else 12.dp,
                        vertical = 6.dp
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = (if (isVhs) Modifier.aspectRatio(4f / 3f)
                    else Modifier.fillMaxWidth().aspectRatio(3f / 4f))
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                        .border(2.dp, skin.finderBorder, RoundedCornerShape(8.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                val current = viewModel.cameraEngine?.zoomRatio?.value ?: 1f
                                viewModel.cameraEngine?.setZoom(current * zoom)
                            }
                        }
                        .pointerInput(Unit) {
                            // タップ位置にピント・露出を合わせる(PHOTOモードのみ有効。判定はエンジン側)
                            detectTapGestures { offset ->
                                // 反応した瞬間に一瞬バイブさせ、タップ位置に赤い印を出す(PHOTO以外・準備前は反応しない)
                                if (viewModel.cameraEngine?.focusAt(offset.x, offset.y) == true) {
                                    tapMarker = offset to ((tapMarker?.second ?: 0) + 1)
                                }
                            }
                        }
                ) {
                    // CameraX Native Preview (High Performance SurfaceView)
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                                scaleType = if (isWide) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
                                cameraEngine.startCamera(this) { qr ->
                                    viewModel.onQrScanned(qr)
                                }
                            }
                        },
                        // Camera binding happens only via CameraEngine (mode / lens / settings changes).
                        // Recomposition must not rebind the camera.
                        update = { previewView ->
                            previewView.scaleType = if (isWide) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // VHS live preview: GL-rendered frames (effect + OSD are burned into the recording too)
                    if (isVhs || gpuPreview) {
                      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        // VHSは4:3の映像を、ひずませずに枠いっぱいに広げる(はみ出した部分は枠で切る)。フィルムは従来どおり
                        val boxW = maxWidth
                        val boxH = maxHeight
                        // VHS(4:3の枠に合わせる)
                        val fitH = boxW * 0.75f
                        val useWidth = fitH <= boxH
                        val coverW = if (useWidth) boxW else boxH * (4f / 3f)
                        val coverH = if (useWidth) fitH else boxH
                        AndroidView(
                            factory = { ctx ->
                                val tv = TextureView(ctx)
                                tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                    override fun onSurfaceTextureAvailable(
                                        surface: SurfaceTexture, width: Int, height: Int
                                    ) {
                                        cameraEngine.attachVhsTextureView(tv)
                                    }

                                    override fun onSurfaceTextureSizeChanged(
                                        surface: SurfaceTexture, width: Int, height: Int
                                    ) {
                                    }

                                    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                        cameraEngine.attachVhsTextureView(null)
                                        return true
                                    }

                                    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                                }
                                tv
                            },
                            modifier = if (isVhs) {
                                Modifier.align(Alignment.Center).requiredSize(coverW, coverH)
                            } else {
                                Modifier.fillMaxSize()
                            }
                        )
                      }
                        (vhsError ?: gpuError)?.let { msg ->
                            Text(
                                text = msg,
                                color = Color(0xFFFFB4AB),
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .padding(16.dp)
                                    .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            )
                        }
                    }

                    // タップ位置の赤い小さい印(3秒で消える)
                    tapMarker?.let { (pos, _) ->
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(color = Color.Red, radius = 6.dp.toPx(), center = pos)
                        }
                    }

                    // 一言メッセージ(保存しました等)をプレビューの真ん中に出す(2.5秒、スワイプで消せる)
                    val toast by viewModel.toastMessage.collectAsState()
                    LaunchedEffect(toast) {
                        if (toast != null) {
                            delay(2500L)
                            viewModel.clearToast()
                        }
                    }
                    toast?.let { msg ->
                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { value ->
                                if (value != SwipeToDismissBoxValue.Settled) viewModel.clearToast()
                                true
                            }
                        )
                        SwipeToDismissBox(
                            state = dismissState,
                            backgroundContent = {},
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 24.dp)
                        ) {
                            Text(
                                text = msg,
                                color = Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF5B82E), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                    }

                    // タップ露出の確認表示(明るさと補正値)
                    tapDebug?.let { msg ->
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // 現像時間の表示(撮影後の数秒だけ)
                    timingDebug?.let { msg ->
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Live Filter simulation overlay (not used in VHS mode: OSD is rendered by the GL pipeline)
                    if (!isVhs && !gpuPreview) {
                        LiveFilterOverlay(
                            mode = currentMode,
                            filterSettings = filterSettings,
                            isLandscape = orientation.isLandscape,
                            hasDateStamp = dateStampEnabled,
                            vignette = vignetteValue / 100f,
                            dateStyle = dateStampStyle
                        )
                    }

                    // Shutter White Flash animation
                    androidx.compose.animation.AnimatedVisibility(
                        visible = shutterFlash,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White)
                        )
                    }

                    // タイマーのカウントダウン表示(中央に大きく)
                    if (countdown > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(120.dp)
                                .background(Color(0x99000000), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = countdown.toString(),
                                color = Color.White,
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // QR scanning reticle
                    if (currentMode == FilmMode.QR) {
                        QrReticleOverlay()
                    }

                    // Pan-Focus indicator badge
                    if (filterSettings.panFocusRestricted && (currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA)) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "過焦点固定 (<1m Bokeh / >=1m Sharp)",
                                color = Color(0xFFFFD54F),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // MOV Video live recording HUD badge (VHS shows its own REC/PLAY OSD in the picture)
                    if (currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            if (isRecording) {
                                val mins = recordingSeconds / 60
                                val secs = recordingSeconds % 60
                                Text(
                                    text = "● REC " + String.format("%02d:%02d", mins, secs),
                                    color = Color(0xFFEF4444),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = "STBY ⏸ (シャッターで録画)",
                                    color = Color(0xFF34D399),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3. Icon bar under the finder (per-mode controls, see IconBar.kt)
            IconBar(
                viewModel = viewModel,
                currentMode = currentMode,
                dateStampEnabled = dateStampEnabled,
                accentColor = accentColor,
                onImportBatch = { multiImagePicker.launch("image/*") },
                onToggleDateStamp = { viewModel.toggleDateStamp() }
            )

            // 5. Bottom Controls (Gallery, Shutter, Multi-Import)
            BottomControlBar(
                latestPhoto = latestPhoto,
                currentMode = currentMode,
                isRecording = isRecording,
                pendingCount = pendingCount,
                recordingSeconds = recordingSeconds,
                flashMode = flashMode,
                accentColor = accentColor,
                skin = skin,
                onOpenGallery = { viewModel.setScreenState(ScreenState.GALLERY) },
                onTriggerShutter = onShutter,
                onToggleFlash = { viewModel.toggleFlash() },
                onSetFlash = { viewModel.setFlash(it) },
                flashMenuOpen = flashMenuOpenState,
                onFlashMenu = { viewModel.setFlashMenu(it) },
                onScanQrFile = { qrImagePicker.launch("image/*") },
                isMovie = currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS,
                isPaused = isPaused,
                onTogglePause = { viewModel.togglePauseRecording() },
                iconAngle = iconAngle,
                showTimer = currentMode == FilmMode.PHOTO || currentMode == FilmMode.FUJI || currentMode == FilmMode.KODA,
                lensAvailable = currentMode == FilmMode.PHOTO && viewModel.lensInstalled,
                lensOn = lensOnState,
                onToggleLens = { viewModel.toggleGoogleLens() },
                timerOn = timerEnabled,
                timerSeconds = timerSeconds,
                onCycleTimer = { viewModel.cycleTimer() }
            )

            // 4. Mode Carousel Switcher(シャッターの行の下・一番下)
            ModeSelector(
                currentMode = currentMode,
                accentColor = accentColor,
                skin = skin,
                onSelectMode = { viewModel.onModeTabTapped(it) }
            )


            Spacer(modifier = Modifier.height(16.dp))
        }


        // Google レンズ: 撮ったあとの確認(誤操作を防ぐため、送る前に必ず聞く)
        lensPending?.let {
            var saveChecked by remember(it) { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { viewModel.cancelLens() },
                title = { Text("Googleレンズに送りますか？", fontWeight = FontWeight.Bold) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = saveChecked, onCheckedChange = { saveChecked = it })
                        Text("端末にも保存する", fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { viewModel.resolveLens(saveChecked) }) { Text("OK") }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.cancelLens() }) { Text("キャンセル") }
                }
            )
        }

        // Batch Progress Indicator HUD
        if (batchProgress.isRunning) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .background(Color(0xFF22201D), RoundedCornerShape(12.dp))
                        .padding(24.dp)
                ) {
                    CircularProgressIndicator(color = Color(0xFFFF8C00))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "一括現像中... (${batchProgress.current}/${batchProgress.total})",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = batchProgress.currentFileName,
                        color = Color(0xFFAAAAAA),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // QR Result Dialog
        scannedQr?.let { qrText ->
            AlertDialog(
                onDismissRequest = { viewModel.clearQrResult() },
                title = { Text("QRコード検出") },
                text = { Text(qrText) },
                confirmButton = {
                    Button(onClick = { viewModel.clearQrResult() }) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, qrText)
                        }
                        context.startActivity(android.content.Intent.createChooser(send, "共有"))
                    }) {
                        Text("共有")
                    }
                }
            )
        }

        // Batch First-Image Confirmation Dialog
        if (showBatchDialog && firstBatchPreview != null) {
            // チェックの状態(開くたびに、どちらも未チェックから始める)
            var batchDateOnly by remember { mutableStateOf(false) }
            var batchCrop by remember { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { viewModel.cancelBatchProcessing() },
                title = {
                    Text(
                        text = "複数画像の一括現像 (${batchUris.size}枚)",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "1枚目の仕上がりプレビュー（縦横比・解像度は完全維持されます）",
                            fontSize = 12.sp,
                            color = Color(0xFFBBBBBB)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        firstBatchPreview?.let { bmp ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(220.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                androidx.compose.foundation.Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "プレビュー",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        // チェック: 日付のみ / トリミングする(どちらも未チェックが既定)
                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Start) {
                            Checkbox(
                                checked = batchDateOnly,
                                onCheckedChange = {
                                    batchDateOnly = it
                                    viewModel.updateBatchPreview(dateOnly = it, crop = batchCrop)
                                }
                            )
                            Text("日付のみ", fontSize = 13.sp, modifier = Modifier.clickable {
                                batchDateOnly = !batchDateOnly
                                viewModel.updateBatchPreview(dateOnly = batchDateOnly, crop = batchCrop)
                            })
                        }
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Start) {
                            Checkbox(
                                checked = batchCrop,
                                onCheckedChange = {
                                    batchCrop = it
                                    viewModel.updateBatchPreview(dateOnly = batchDateOnly, crop = it)
                                }
                            )
                            Text("トリミングする(中央・縦3:4 / 横4:3)", fontSize = 13.sp, modifier = Modifier.clickable {
                                batchCrop = !batchCrop
                                viewModel.updateBatchPreview(dateOnly = batchDateOnly, crop = batchCrop)
                            })
                        }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "2枚目以降はバックグラウンドで連続現像されます。",
                            fontSize = 11.sp,
                            color = Color(0xFFFF8C00)
                        )
                    }
                },
                confirmButton = {
                    // 一行で表示する(入りきらないときは文字を小さくする)
                    Button(
                        onClick = { viewModel.confirmBatchProcessing(dateOnly = batchDateOnly, crop = batchCrop) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8C00))
                    ) {
                        Text(
                            "加工して保存",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.cancelBatchProcessing() }) {
                        Text("キャンセル")
                    }
                }
            )
        }

        // Settings / Film Tweaks Dialog
        if (showSettingsDialog) {
            FilmSettingsDialog(
                settings = filterSettings,
                prefs = viewModel.prefs,
                viewModel = viewModel,
                onDismiss = { showSettingsDialog = false },
                onUpdate = { viewModel.updateFilterSettings(it) }
            )
        }
    }
}

@Composable
fun TopToolbar(
    currentMode: FilmMode,
    flashMode: FlashMode,
    dateStampEnabled: Boolean,
    soundEnabled: Boolean,
    onToggleSound: () -> Unit,
    accentColor: Color,
    skin: CameraSkin,
    onToggleLens: () -> Unit,
    onOpenSettings: () -> Unit,
    iconAngle: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(skin.topBar)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title & Mode (takes the left half; icons share the right half evenly)
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(
                    text = "Mellow Film",
                    fontWeight = FontWeight.Black,
                    color = skin.topText,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
                // 新旧の混同防止用。完成したら削除する
                val versionCtx = LocalContext.current
                val versionText = remember(versionCtx) {
                    runCatching { versionCtx.packageManager.getPackageInfo(versionCtx.packageName, 0).versionName }
                        .getOrNull() ?: ""
                }
                Text(
                    text = "v$versionText",
                    color = skin.topText.copy(alpha = 0.6f),
                    fontSize = 8.sp
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .background(accentColor, RoundedCornerShape(3.dp))
                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
            ) {
                Text(
                    text = currentMode.id,
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        // Quick Controls (equal spacing)
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Front / back camera switch
            IconButton(modifier = Modifier.rotate(iconAngle), onClick = onToggleLens) {
                Icon(
                    imageVector = Icons.Default.Cameraswitch,
                    contentDescription = "カメラ切替",
                    tint = skin.topIcon
                )
            }

            // Shutter sound toggle (back in the top bar)
            IconButton(modifier = Modifier.rotate(iconAngle), onClick = onToggleSound) {
                Icon(
                    imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "シャッター音",
                    tint = skin.topIcon.copy(alpha = if (soundEnabled) 1f else 0.35f)
                )
            }

            // Detailed Settings
            IconButton(modifier = Modifier.rotate(iconAngle), onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "設定",
                    tint = skin.topIcon
                )
            }
        }
    }
}

@Composable
fun LiveFilterOverlay(
    mode: FilmMode,
    filterSettings: FilterSettings,
    isLandscape: Boolean,
    hasDateStamp: Boolean,
    vignette: Float,
    dateStyle: DateStampStyle = DateStampStyle()
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Vignette simulation (strength from the settings screen). フィルムモード(FUJI・KODA)だけ
        val filmMode = mode == FilmMode.FUJI || mode == FilmMode.KODA
        if (vignette > 0f && filmMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            // Many stops with a smoothstep ease: no visible banding between steps
                            colorStops = Array(12) { i ->
                                val t = i / 11f
                                val ease = t * t * (3f - 2f * t)
                                (0.45f + 0.55f * t) to Color.Black.copy(
                                    alpha = (vignette * 0.75f * ease).coerceIn(0f, 1f)
                                )
                            }
                        )
                    )
            )
        }

        // Mode-specific color tint
        when (mode) {
            FilmMode.FUJI -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x18FF5533)) // Warm reddish disposable tint
                )
            }
            FilmMode.KODA -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x15FFAA33)) // Golden amber soft gradation
                )
            }
            FilmMode.MOV, FilmMode.MOV_VHS -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x1200E5FF))
                )
            }
            else -> {}
        }

        // Live date stamp preview: same look as the saved photo (font, colours, position, opacity)
        if (hasDateStamp && (mode == FilmMode.FUJI || mode == FilmMode.KODA)) {
            val dateStr = remember { DateStampRenderer.extractDateString(null) }
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawIntoCanvas { c ->
                    // 横持ちでも位置は動かさず、左下・縦書きに固定する(案A・試験)
                    DateStampRenderer.drawStamp(c.nativeCanvas, size.width, size.height, dateStr, false, dateStyle)
                }
            }
        }
    }
}

@Composable
fun QrReticleOverlay() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(12.dp))
        )
        Text(
            text = "QRコードを枠に合わせてください",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ModeSelector(
    currentMode: FilmMode,
    accentColor: Color,
    skin: CameraSkin,
    onSelectMode: (FilmMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(skin.modeBar)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Fixed tab order (do not change): FUJI / KODA / PHOTO / MOV / QR
        // The MOV tab also covers MOV_VHS; tapping MOV again toggles MOV <-> VHS.
        val tabs = listOf(FilmMode.FUJI, FilmMode.KODA, FilmMode.PHOTO, FilmMode.MOV, FilmMode.QR)
        tabs.forEach { mode ->
            val isMovTab = mode == FilmMode.MOV
            val isSelected = currentMode == mode || (isMovTab && currentMode == FilmMode.MOV_VHS)
            val label = if (isMovTab && currentMode == FilmMode.MOV_VHS) "VHS" else mode.id
            // 5つのタブを同じ幅にして、PHOTO(真ん中)が必ず左右の中心に来るようにする
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isSelected) skin.modeSelected else skin.modeIdle,
                fontSize = if (isSelected) 14.sp else 12.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                // 「PHOTO」が二行に折れないよう、折り返しを止めて余白を詰める
                softWrap = false,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        (if (isSelected) skin.modePill else null) ?: Color.Transparent,
                        RoundedCornerShape(16.dp)
                    )
                    .clickable { onSelectMode(mode) }
                    .padding(horizontal = 4.dp, vertical = 6.dp)
            )
            }
        }
    }
}

@Composable
fun BottomControlBar(
    latestPhoto: com.mellowfilm.pro.data.model.FilmPhoto?,
    currentMode: FilmMode,
    isRecording: Boolean = false,
    recordingSeconds: Long = 0L,
    flashMode: FlashMode,
    accentColor: Color,
    skin: CameraSkin,
    onOpenGallery: () -> Unit,
    onTriggerShutter: () -> Unit,
    onToggleFlash: () -> Unit,
    onSetFlash: (FlashMode) -> Unit = {},
    flashMenuOpen: Boolean = false,
    onFlashMenu: (Boolean) -> Unit = {},
    iconAngle: Float = 0f,
    onScanQrFile: () -> Unit,
    isMovie: Boolean = false,
    isPaused: Boolean = false,
    pendingCount: Int = 0,
    onTogglePause: () -> Unit = {},
    showTimer: Boolean = false,
    lensAvailable: Boolean = false,
    lensOn: Boolean = false,
    onToggleLens: () -> Unit = {},
    timerOn: Boolean = false,
    timerSeconds: Int = 3,
    onCycleTimer: () -> Unit = {}
) {
    // Shutter sits at the true horizontal center; gallery (left) and flash (right) are pinned to the edges
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(84.dp)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // 画面の幅から、小窓(左端 54dp)とシャッター(中央 ±38dp)の間の中央を計算する
        val maxW = maxWidth
        // Left: Developed Film Gallery Thumbnail
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(skin.buttonFill, RoundedCornerShape(10.dp))
                .border(1.5.dp, skin.ring, RoundedCornerShape(10.dp))
                .align(Alignment.CenterStart)
                .clickable(onClick = onOpenGallery),
            contentAlignment = Alignment.Center
        ) {
            if (latestPhoto != null) {
                AsyncImage(
                    model = Uri.parse(latestPhoto.uriString),
                    contentDescription = "現像アルバム",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = Color(0xFF888277),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Center: Shutter / Video Record Button
        run {
            // Retro Film Winding Shutter Button / Video Record Button
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(skin.shutterCore)
                    .border(
                        3.dp,
                        if ((currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) && isRecording) Color(0xFFEF4444) else skin.ring,
                        CircleShape
                    )
                    .clickable {
                        if (currentMode == FilmMode.QR) {
                            onScanQrFile()
                        } else {
                            onTriggerShutter()
                        }
                    }
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                if (currentMode == FilmMode.MOV || currentMode == FilmMode.MOV_VHS) {
                    if (isRecording) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFEF4444))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Color(0xFFE11D48))
                                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                        }
                    }
                } else if (currentMode == FilmMode.QR) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "QRスキャン",
                        // White icon on the bright shutter fill
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(skin.shutterCore)
                            .border(2.dp, skin.ring, CircleShape)
                    )
                }

                // 現像中: リングをくるくる回す(シャッターは押せたままで、枚数が0になると止まって元に戻る)
                if (pendingCount > 0) {
                    CircularProgressIndicator(
                        modifier = Modifier.matchParentSize(),
                        color = Color.White,
                        strokeWidth = 3.dp
                    )
                }
            }

            // Pause / resume button: small, right of the shutter, only while recording a movie
            if (isMovie && isRecording) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(x = 62.dp)
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(skin.buttonFill, CircleShape)
                        .border(1.5.dp, skin.ring, CircleShape)
                        .clickable(onClick = onTogglePause),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isPaused) "再開" else "一時停止",
                        tint = skin.buttonIcon,
                        modifier = Modifier.size(18.dp).rotate(iconAngle)
                    )
                }
            }

            // Google レンズのボタン(シャッターとフラッシュの間・中央対称。PHOTO のみ。枠と背景はなし)
            if (lensAvailable) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(x = maxW / 4f - 8.dp)
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onToggleLens),
                    contentAlignment = Alignment.Center
                ) {
                    MaterialSymbol(
                        name = "image_search",
                        tint = if (lensOn) Color(0xFFF5B82E) else skin.buttonIcon,
                        size = 24.dp,
                        modifier = Modifier.rotate(iconAngle)
                    )
                }
            }

            // Flash button (right edge): 押すとメニュー(トーチ・オン)が上へスライドして出る。
            // オン/トーチのときに押すとオフに戻る。枠・背景なし、アイコンと文字だけ
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(54.dp)
                    .clickable {
                        if (flashMode != FlashMode.OFF) {
                            onSetFlash(FlashMode.OFF)
                            onFlashMenu(false)
                        } else {
                            onFlashMenu(!flashMenuOpen)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = flashIcon(flashMode),
                        contentDescription = "フラッシュ",
                        tint = flashTint(flashMode),
                        modifier = Modifier.size(22.dp).rotate(iconAngle)
                    )
                    Text(
                        text = flashLabel(flashMode),
                        fontSize = 9.sp,
                        color = flashTint(flashMode),
                        fontWeight = FontWeight.Bold
                    )
                }

                // メニュー(トーチ・オンだけ)。フラッシュボタンの真上へスライドして出る
                AnimatedVisibility(
                    visible = flashMenuOpen,
                    modifier = Modifier.align(Alignment.TopCenter).offset(y = (-104).dp),
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    // メニューの背景は、カメラのボディと同じ色
                    // フラッシュボタン(54dp)より大きいので、サイズを固定して はみ出しても切られないようにする
                    Column(
                        modifier = Modifier
                            .requiredSize(62.dp, 100.dp)
                            .background(skin.body, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FlashOption(
                            mode = FlashMode.TORCH,
                            selected = flashMode == FlashMode.TORCH,
                            onClick = {
                                onSetFlash(FlashMode.TORCH)
                                onFlashMenu(false)
                            }
                        )
                        FlashOption(
                            mode = FlashMode.ON,
                            selected = flashMode == FlashMode.ON,
                            onClick = {
                                onSetFlash(FlashMode.ON)
                                onFlashMenu(false)
                            }
                        )
                    }
                }
            }
        }
    }
}

/** フラッシュの状態に応じた色(オン・トーチは黄色の点灯、オフは白の35%) */
private fun flashTint(mode: FlashMode): Color =
    if (mode != FlashMode.OFF) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.35f)

private fun flashIcon(mode: FlashMode): ImageVector = when (mode) {
    FlashMode.OFF -> Icons.Default.FlashOff
    FlashMode.ON -> Icons.Default.FlashOn
    FlashMode.TORCH -> Icons.Default.FlashlightOn
}

private fun flashLabel(mode: FlashMode): String = when (mode) {
    FlashMode.OFF -> "OFF"
    FlashMode.ON -> "ON"
    FlashMode.TORCH -> "TORCH"
}

/** フラッシュメニューの1項目(アイコンと文字。選ばれた項目は点灯) */
@Composable
private fun FlashOption(mode: FlashMode, selected: Boolean, onClick: () -> Unit) {
    val tint = if (selected) flashTint(mode) else Color.White.copy(alpha = 0.35f)
    Column(
        modifier = Modifier
            .width(54.dp)
            .height(46.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(imageVector = flashIcon(mode), contentDescription = flashLabel(mode), tint = tint, modifier = Modifier.size(22.dp))
        Text(text = flashLabel(mode), fontSize = 9.sp, color = tint, fontWeight = FontWeight.Bold)
    }
}

/**
 * タイマー撮影の設定ポップアップ。ラジオボタンで 3秒 / 5秒 / 10秒 / オフ を選び、OKで確定する。
 * 値は null = オフ。
 */
@Composable
fun TimerDialog(
    enabled: Boolean,
    seconds: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int?) -> Unit
) {
    // 今の設定を初期値にする(オフ中は直前の秒数=初期値 3 秒を選んだ状態にする)
    var selected by remember { mutableStateOf<Int?>(if (enabled) seconds else null) }
    val options: List<Pair<Int?, String>> = listOf(3 to "3秒", 5 to "5秒", 10 to "10秒", null to "オフ")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("タイマー撮影", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selected = value }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected == value, onClick = { selected = value })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, fontSize = 15.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selected) }) { Text("OK", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("キャンセル") }
        }
    )
}

/** 設定画面の1行分の選択肢(選択中は黄色の丸いチップ) */
@Composable
fun <T> PresetRow(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(
            modifier = Modifier
                .padding(top = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEach { (value, label) ->
                val on = value == selected
                Text(
                    text = label,
                    softWrap = false,
                    color = if (on) Color.Black else Color(0xFF444444),
                    fontSize = 12.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .background(
                            if (on) Color(0xFFF5B82E) else Color(0xFFE5E5E5),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelect(value) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun FilmSettingsDialog(
    settings: FilterSettings,
    prefs: AppPrefs,
    viewModel: MellowFilmViewModel,
    onDismiss: () -> Unit,
    onUpdate: (FilterSettings) -> Unit
) {
    var panFocus by remember { mutableStateOf(settings.panFocusRestricted) }
    var showCameraInfo by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("詳細設定", fontWeight = FontWeight.Bold) },
        text = {
            val scrollState = rememberScrollState()
            var viewportPx by remember { mutableStateOf(0) }
            Box(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .onSizeChanged { viewportPx = it.height }
            ) {
            Column(
                modifier = Modifier
                    .verticalScroll(scrollState)
                    .padding(end = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("過焦点パンフォーカス", fontWeight = FontWeight.Bold)
                        Text("1m未満ボケ / 1m以上ピント固定", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = panFocus, onCheckedChange = { panFocus = it })
                }

                Spacer(modifier = Modifier.height(10.dp))

                // インカメラの左右反転(PHOTOのみ。保存する写真だけ反転し、プレビューは反転しない)
                val mirrorOn by prefs.mirrorFront.collectAsState()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("インカメラを反転させる（PHOTOモードのみ）", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Switch(checked = mirrorOn, onCheckedChange = { prefs.setMirrorFront(it) })
                }

                Spacer(modifier = Modifier.height(10.dp))


                ProcessingSettings(viewModel = viewModel)

                Spacer(modifier = Modifier.height(16.dp))

            }

            // Simple scrollbar: thumb size and position follow the scroll state
            if (scrollState.maxValue > 0 && viewportPx > 0) {
                val density = LocalDensity.current
                val contentPx = viewportPx + scrollState.maxValue
                val thumbPx = (viewportPx.toFloat() * viewportPx / contentPx).toInt().coerceAtLeast(24)
                val offsetPx = ((viewportPx - thumbPx) * scrollState.value.toFloat() / scrollState.maxValue).toInt()
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset { IntOffset(0, offsetPx) }
                        .width(4.dp)
                        .height(with(density) { thumbPx.toDp() })
                        .background(Color(0xFF888888), RoundedCornerShape(2.dp))
                )
            }
            }
        },
        confirmButton = {
            Button(onClick = {
                onUpdate(
                    settings.copy(
                        panFocusRestricted = panFocus
                    )
                )
                onDismiss()
            }) {
                Text("適用")
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { showCameraInfo = true }) {
                    Text("カメラ情報")
                }
                TextButton(onClick = onDismiss) {
                    Text("閉じる")
                }
            }
        }
    )

    // 端末のカメラ情報(マクロ対応の確認用)
    if (showCameraInfo) {
        val ctx = LocalContext.current
        val info = remember { com.mellowfilm.pro.camera.CameraInfo.describe(ctx) }
        AlertDialog(
            onDismissRequest = { showCameraInfo = false },
            title = { Text("カメラ情報", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(info, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = {
                TextButton(onClick = { showCameraInfo = false }) {
                    Text("閉じる")
                }
            }
        )
    }
}

/** Context から Activity を探す(画面の明るさを変えるために使う) */
private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is android.content.ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** この画面だけの明るさを変える。-1 でシステム設定に戻る */
private fun setScreenBrightness(window: android.view.Window?, value: Float) {
    window ?: return
    val attrs = window.attributes
    attrs.screenBrightness = value
    window.attributes = attrs
}
