package com.mellowfilm.pro.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mellowfilm.pro.MellowFilmApplication
import com.mellowfilm.pro.camera.CameraEngine
import com.mellowfilm.pro.camera.DeviceOrientation
import com.mellowfilm.pro.camera.FlashMode
import com.mellowfilm.pro.camera.OrientationManager
import com.mellowfilm.pro.camera.SoundManager
import com.mellowfilm.pro.data.prefs.AppPrefs
import com.mellowfilm.pro.filter.BatchProcessor
import com.mellowfilm.pro.filter.BatchProgress
import com.mellowfilm.pro.filter.DateStampRenderer
import com.mellowfilm.pro.vhs.VhsOsdState
import com.mellowfilm.pro.filter.FilmMode
import com.mellowfilm.pro.filter.FilterSettings
import com.mellowfilm.pro.lut.LutRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ScreenState {
    CAMERA, GALLERY
}

class MellowFilmViewModel(application: Application) : AndroidViewModel(application) {
    val database = (application as MellowFilmApplication).database
    val soundManager = SoundManager(application)
    val orientationManager = OrientationManager(application)
    val batchProcessor = BatchProcessor(application, database)
    val prefs = AppPrefs(application)

    var cameraEngine: CameraEngine? = null

    // Screen Navigation
    private val _screenState = MutableStateFlow(ScreenState.CAMERA)
    val screenState: StateFlow<ScreenState> = _screenState.asStateFlow()

    // Camera Mode
    private val _currentMode = MutableStateFlow(FilmMode.PHOTO)
    val currentMode: StateFlow<FilmMode> = _currentMode.asStateFlow()

    // Flash & Shutter Controls
    private val _flashMode = MutableStateFlow(FlashMode.OFF)
    val flashMode: StateFlow<FlashMode> = _flashMode.asStateFlow()

    private val _soundEnabled = MutableStateFlow(prefs.shutterSound.value)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _dateStampEnabled = MutableStateFlow(true)
    val dateStampEnabled: StateFlow<Boolean> = _dateStampEnabled.asStateFlow()

    // Filter Settings (panFocus / sound; grain and vignette live in AppPrefs)
    private val _filterSettings = MutableStateFlow(FilterSettings(enableSound = prefs.shutterSound.value))
    val filterSettings: StateFlow<FilterSettings> = _filterSettings.asStateFlow()

    // Exposure EV (-2 .. +2)
    // マクロ(近距離固定): この端末で使えるか。使えるときだけ PHOTO に「マクロ」を出す
    val macroAvailable: Boolean = com.mellowfilm.pro.camera.CameraInfo.macroFocusAvailable(application) ||
        com.mellowfilm.pro.camera.CameraInfo.macroPhysicalId(application) != null
    private val _macroOn = MutableStateFlow(false)
    val macroOn: StateFlow<Boolean> = _macroOn.asStateFlow()

    // Google レンズ: 使える端末かどうか(使えない端末ではボタンを出さない)と、オン・オフ
    val lensInstalled: Boolean = com.mellowfilm.pro.camera.LensShare.isInstalled(application)
    val lensOn: StateFlow<Boolean> = com.mellowfilm.pro.camera.LensShare.hold

    fun toggleGoogleLens() {
        com.mellowfilm.pro.camera.LensShare.hold.value = !com.mellowfilm.pro.camera.LensShare.hold.value
    }

    fun resolveLens(saveToGallery: Boolean) {
        cameraEngine?.resolveLens(saveToGallery)
    }

    fun cancelLens() {
        cameraEngine?.cancelLens()
    }

    fun toggleMacro() {
        _macroOn.value = !_macroOn.value
        cameraEngine?.setMacro(_macroOn.value)
    }

    private val _exposureEV = MutableStateFlow(0)
    val exposureEV: StateFlow<Int> = _exposureEV.asStateFlow()

    // QR Scanned code result
    private val _scannedQrCode = MutableStateFlow<String?>(null)
    val scannedQrCode: StateFlow<String?> = _scannedQrCode.asStateFlow()

    // Batch Import State
    private val _batchUris = MutableStateFlow<List<Uri>>(emptyList())
    val batchUris: StateFlow<List<Uri>> = _batchUris.asStateFlow()

    private val _firstBatchPreview = MutableStateFlow<Bitmap?>(null)
    val firstBatchPreview: StateFlow<Bitmap?> = _firstBatchPreview.asStateFlow()

    private val _showBatchDialog = MutableStateFlow(false)
    val showBatchDialog: StateFlow<Boolean> = _showBatchDialog.asStateFlow()

    // Shutter Trigger Pulse
    private val _shutterFlash = MutableStateFlow(false)
    val shutterFlash: StateFlow<Boolean> = _shutterFlash.asStateFlow()

    val batchProgress: StateFlow<BatchProgress> = batchProcessor.progress
    val deviceOrientation: StateFlow<DeviceOrientation> = orientationManager.orientation

    init {
        orientationManager.start()
        // Load saved FUJI / KODA LUTs in the background; the cache is swapped on each change
        viewModelScope.launch(Dispatchers.IO) {
            LutRepository.reloadAll(application, prefs)
        }
        // 日付スタンプ用フォント: 起動時に同期で読み込む(撮影・プレビューより前に確実に使えるように)
        DateStampRenderer.loadFont(application)
        // VHS OSD用フォント(assets/fonts/vhs_osd.ttf)
        com.mellowfilm.pro.vhs.VhsOsdState.loadOsdFont(application)
        VhsOsdState.osdEnabled = prefs.vhsOsd.value
    }

    fun setScreenState(state: ScreenState) {
        _screenState.value = state
    }

    // 前面カメラかどうか(前面のときだけ「左右反転」ボタンを出す)
    private val _frontLens = MutableStateFlow(false)
    val frontLens: StateFlow<Boolean> = _frontLens.asStateFlow()

    // タイマー撮影: オン/オフと秒数(初期値 3 秒)。カウント中は countdown が 3,2,1 と減る(0 = 停止中)
    private val _timerEnabled = MutableStateFlow(false)
    val timerEnabled: StateFlow<Boolean> = _timerEnabled.asStateFlow()

    private val _timerSeconds = MutableStateFlow(3)
    val timerSeconds: StateFlow<Int> = _timerSeconds.asStateFlow()

    private val _countdown = MutableStateFlow(0)
    val countdown: StateFlow<Int> = _countdown.asStateFlow()

    private var countdownJob: Job? = null

    /** タイマーを設定する。null でオフ */
    fun setTimer(seconds: Int?) {
        cancelCountdown()
        if (seconds == null) {
            _timerEnabled.value = false
        } else {
            _timerSeconds.value = seconds
            _timerEnabled.value = true
        }
    }

    /** タイマーの切り替え: OFF → 3秒 → 5秒 → 10秒 → OFF … の順に進める */
    fun cycleTimer() {
        val next: Int? = when {
            !_timerEnabled.value -> 3
            _timerSeconds.value == 3 -> 5
            _timerSeconds.value == 5 -> 10
            else -> null
        }
        setTimer(next)
    }

    private fun cancelCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        _countdown.value = 0
    }

    /**
     * シャッターを押したときの入口。
     * - カウント中にもう一度押したら、タイマーを取り消す(撮らない)
     * - 静止画でタイマーがオンなら、カウントダウンしてから capture を呼ぶ
     * - それ以外は、すぐ capture を呼ぶ
     */
    fun onShutterPressed(capture: () -> Unit) {
        if (countdownJob?.isActive == true) {
            cancelCountdown()
            return
        }
        val isStill = _currentMode.value != FilmMode.MOV && _currentMode.value != FilmMode.MOV_VHS
        if (isStill && _timerEnabled.value) {
            val total = _timerSeconds.value
            countdownJob = viewModelScope.launch {
                try {
                    for (s in total downTo 1) {
                        _countdown.value = s
                        delay(1000L)
                    }
                    _countdown.value = 0
                    capture()
                } finally {
                    _countdown.value = 0
                }
            }
        } else {
            capture()
        }
    }

    fun setMode(mode: FilmMode) {
        cancelCountdown()
        _currentMode.value = mode
        cameraEngine?.updateSettings(
            mode = mode,
            settings = _filterSettings.value,
            dateStamp = _dateStampEnabled.value,
            sound = _soundEnabled.value
        )
    }

    /**
     * Mode tab tap handler.
     * Tab order is fixed: FUJI / KODA / PHOTO / MOV / QR.
     * Tapping MOV while already in a movie mode toggles MOV <-> MOV_VHS (sub-mode).
     */
    fun onModeTabTapped(tab: FilmMode) {
        // Switching modes rebinds the camera, so ignore taps while recording
        if (cameraEngine?.isRecording?.value == true) return
        val current = _currentMode.value
        val next = if (tab == FilmMode.MOV && (current == FilmMode.MOV || current == FilmMode.MOV_VHS)) {
            if (current == FilmMode.MOV) FilmMode.MOV_VHS else FilmMode.MOV
        } else {
            tab
        }
        if (next != current) setMode(next)
    }

    fun toggleLens() {
        cameraEngine?.toggleLens()
        _frontLens.value = cameraEngine?.isFrontLens ?: false
    }

    private val _flashMenuOpen = MutableStateFlow(false)
    val flashMenuOpen: StateFlow<Boolean> = _flashMenuOpen.asStateFlow()

    fun setFlashMenu(open: Boolean) {
        _flashMenuOpen.value = open
    }

    /** フラッシュを指定の状態にする(メニューから選んだとき) */
    fun setFlash(mode: FlashMode) {
        _flashMode.value = mode
        cameraEngine?.setFlashMode(mode)
    }

    fun toggleFlash() {
        val next = when (_flashMode.value) {
            FlashMode.OFF -> FlashMode.ON
            FlashMode.ON -> FlashMode.TORCH
            FlashMode.TORCH -> FlashMode.OFF
        }
        _flashMode.value = next
        cameraEngine?.setFlashMode(next)
    }

    fun toggleDateStamp() {
        _dateStampEnabled.value = !_dateStampEnabled.value
        cameraEngine?.updateSettings(
            mode = _currentMode.value,
            settings = _filterSettings.value,
            dateStamp = _dateStampEnabled.value,
            sound = _soundEnabled.value
        )
    }

    /** VHSの焼き付け文字(REC/PLAY・SP・日付)の有り無し。保存する */
    val vhsOsd: StateFlow<Boolean> get() = prefs.vhsOsd

    fun toggleVhsOsd() {
        val next = !prefs.vhsOsd.value
        prefs.setVhsOsd(next)
        VhsOsdState.osdEnabled = next
    }

    fun togglePauseRecording() {
        cameraEngine?.togglePauseRecording()
    }

    /** 上部ツールバーのシャッター音ボタン。設定値として保存する */
    fun toggleSound() {
        updateFilterSettings(_filterSettings.value.copy(enableSound = !_soundEnabled.value))
    }

    fun updateFilterSettings(newSettings: FilterSettings) {
        _filterSettings.value = newSettings
        // Shutter sound: single source of truth (toolbar button), persisted
        _soundEnabled.value = newSettings.enableSound
        prefs.setShutterSound(newSettings.enableSound)
        cameraEngine?.updateSettings(
            mode = _currentMode.value,
            settings = newSettings,
            dateStamp = _dateStampEnabled.value,
            sound = newSettings.enableSound
        )
    }

    /** 選んだ .cube を登録する。読めなければ false */
    fun setLut(mode: FilmMode, uri: Uri): Boolean =
        LutRepository.setUri(getApplication(), prefs, mode, uri)

    fun clearLut(mode: FilmMode) {
        LutRepository.clear(getApplication(), prefs, mode)
    }

    fun setExposureEV(ev: Int) {
        _exposureEV.value = ev.coerceIn(-5, 5)
        cameraEngine?.setExposureIndex(ev)
    }

    val isRecording: StateFlow<Boolean>
        get() = cameraEngine?.isRecording ?: MutableStateFlow(false)

    val recordingSeconds: StateFlow<Long>
        get() = cameraEngine?.recordingSeconds ?: MutableStateFlow(0L)

    /** 白い閃光(シャッター演出)のオン/オフ。前面カメラの疑似フラッシュで使う */
    fun setShutterFlash(on: Boolean) {
        _shutterFlash.value = on
    }

    fun triggerShutter() {
        if (_currentMode.value == FilmMode.MOV || _currentMode.value == FilmMode.MOV_VHS) {
            cameraEngine?.toggleRecording()
        } else {
            onShutterPressed {
                _shutterFlash.value = true
                viewModelScope.launch {
                    kotlinx.coroutines.delay(120)
                    _shutterFlash.value = false
                }
                cameraEngine?.takePhoto()
            }
        }
    }

    fun onQrScanned(code: String) {
        if (_scannedQrCode.value != code) {
            _scannedQrCode.value = code
        }
    }

    fun clearQrResult() {
        _scannedQrCode.value = null
    }

    fun onBatchImagesSelected(uris: List<Uri>) {
        if (uris.isEmpty()) return
        _batchUris.value = uris

        viewModelScope.launch {
            val previewData = batchProcessor.prepareFirstImagePreview(
                uri = uris[0],
                mode = _currentMode.value,
                hasDateStamp = _dateStampEnabled.value,
                vignette = prefs.vignette.value / 100f,
                grain = prefs.grain.value / 100f
            )
            _firstBatchPreview.value = previewData?.first
            _showBatchDialog.value = true
        }
    }

    // 画面下に出す一言メッセージ(スワイプで消せる。null = 表示しない)
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    /** 確認画面のチェックが変わったとき、1枚目のプレビューを作り直す */
    fun updateBatchPreview(dateOnly: Boolean, crop: Boolean) {
        val uri = _batchUris.value.firstOrNull() ?: return
        viewModelScope.launch {
            val previewData = batchProcessor.prepareFirstImagePreview(
                uri = uri,
                mode = _currentMode.value,
                hasDateStamp = _dateStampEnabled.value,
                vignette = prefs.vignette.value / 100f,
                grain = prefs.grain.value / 100f,
                dateOnly = dateOnly,
                crop = crop,
                dateStyle = prefs.dateStampStyle.value
            )
            _firstBatchPreview.value = previewData?.first
        }
    }

    /**
     * 確認画面の「加工して保存」。
     * dateOnly = true のときは日付だけ入れて保存する(フィルムの加工はしない)。
     * crop = true のときは中央で 3:4(縦)/ 4:3(横)に切り抜いてから保存する。
     */
    fun confirmBatchProcessing(dateOnly: Boolean = false, crop: Boolean = false) {
        _showBatchDialog.value = false
        val uris = _batchUris.value
        if (uris.isEmpty()) return

        viewModelScope.launch {
            val saved = batchProcessor.processBatch(
                uris = uris,
                mode = _currentMode.value,
                hasDateStamp = _dateStampEnabled.value,
                vignette = prefs.vignette.value / 100f,
                grain = prefs.grain.value / 100f,
                quality = if (_currentMode.value == FilmMode.PHOTO) 90 else 80,
                dateOnly = dateOnly,
                dateStyle = prefs.dateStampStyle.value,
                crop = crop
            )
            // 全部保存できたら「保存しました」。一部だけなら、何枚できたかを出す
            showToast(
                if (saved == uris.size) "保存しました"
                else "保存できたのは ${saved}/${uris.size} 枚です"
            )
            _batchUris.value = emptyList()
            _firstBatchPreview.value = null
        }
    }

    fun cancelBatchProcessing() {
        _showBatchDialog.value = false
        _batchUris.value = emptyList()
        _firstBatchPreview.value = null
    }

    override fun onCleared() {
        super.onCleared()
        orientationManager.stop()
        soundManager.release()
        cameraEngine?.release()
    }
}
